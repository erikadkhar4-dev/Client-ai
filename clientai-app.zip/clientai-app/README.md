# ⚡ ClientAI

> AI-Powered Client Acquisition Platform — Built for India & Global Markets

## 🚀 What's Inside

| Feature | Details |
|---------|---------|
| 🏠 Landing Page | Professional hero, stats, 10 tool cards |
| 🔐 Auth System | Sign up / Log in / OTP / Google |
| 📊 Dashboard | Stats, quick actions, 3D tool cards with stickers |
| ⚡ Strategy Generator | Real AI — full plan + WhatsApp + Email |
| 👥 Client Tracker | Pipeline, status, notes |
| 📱 Social Posts | 3 posts + hashtags per platform |
| 💰 Pricing Calculator | Market-based pricing advice |
| 🧾 Invoice Generator | 10 currencies, professional format |
| 📄 Proposal Builder | AI-written winning proposals |
| 🔔 Follow-up Manager | Reminders + AI messages |
| ✨ Business Name AI | 10 names + taglines |
| 🔍 Competitor Analysis | Market gaps + win tactics |
| 📂 Strategy History | Auto-saved, searchable |
| 💱 Dual Currency | USD + INR pricing |
| 🌍 24 Languages | Full AI output in any language |
| 🌓 Dark / Light Mode | Both themes |
| 📱 Mobile Ready | Bottom nav, responsive |
| 🔔 Toast Notifications | Copy, download, upgrade alerts |

---

## ⚡ Quick Start (3 steps)

```bash
# Step 1 — Install dependencies
npm install

# Step 2 — Run locally
npm run dev
# Opens at http://localhost:3000

# Step 3 — Build for production
npm run build
# Output in /dist folder
```

---

## 🌐 Deploy Free in 60 Seconds

### Vercel (Recommended)
1. Push to GitHub
2. Go to vercel.com → New Project → Import repo
3. Click Deploy — done!

### Netlify
1. Run `npm run build`
2. Drag `/dist` folder to netlify.com/drop
3. Done!

---

## 🔐 Demo Login
```
Email:    demo@clientai.com
Password: demo1234
```

---

## 💰 Pricing (USD & INR)

| Plan | USD/mo | INR/mo |
|------|--------|--------|
| Free | $0 | ₹0 |
| Pro | $9 | ₹299 |
| Agency | $29 | ₹999 |
| Enterprise | $99 | ₹2,999 |

---

## 💳 Payment Methods Supported

| Method | Region |
|--------|--------|
| 🇮🇳 UPI (Google Pay, PhonePe, Paytm) | India |
| 🇮🇳 Razorpay (Cards, Net Banking, EMI) | India |
| 🌍 Stripe (Visa, Mastercard, Amex) | Global |
| 🌍 PayPal | Global |
| 🏦 Bank Transfer (NEFT/RTGS/SWIFT) | Both |
| 🔗 Crypto (USDT, BTC, ETH) | Global |

---

## 🔑 Environment Variables

Copy `.env.local.example` to `.env.local` and fill in:

```env
VITE_ANTHROPIC_KEY=sk-ant-...     # Required for AI
VITE_RAZORPAY_KEY=rzp_live_...    # India payments
VITE_STRIPE_KEY=pk_live_...       # International cards
VITE_PAYPAL_CLIENT_ID=...         # PayPal
VITE_UPI_ID=yourname@upi          # UPI payments
```

---

## 🛠 Tech Stack

- **React 18** — UI framework
- **Vite 5** — Build tool (fast!)
- **Claude AI API** — claude-sonnet-4-6
- **CSS-in-JS** — No extra styling libraries needed
- **Node 18+** required

---

## 📁 Project Structure

```
clientai-app/
├── public/
│   ├── favicon.svg       ← App icon
│   ├── og-image.svg      ← Social share image
│   └── robots.txt        ← SEO
├── src/
│   ├── App.jsx           ← Full app (1100+ lines)
│   ├── main.jsx          ← Entry point
│   └── index.css         ← Global styles
├── index.html            ← App shell + meta tags
├── package.json          ← Dependencies
├── vite.config.js        ← Build config
├── vercel.json           ← Vercel deploy config
├── netlify.toml          ← Netlify deploy config
├── .env.local.example    ← Environment template
├── .gitignore
└── README.md
```

---

## 📈 Go-to-Market — India Strategy

1. **Week 1-2** — Post in Indian freelancer Facebook/LinkedIn groups
2. **Week 3-4** — Charge first ₹299/month users
3. **Month 2** — Approach digital agencies
4. **Month 3-6** — Enterprise ($99/₹2,999) plan for startups

---

Built with ❤️ using Claude AI · Target Market: India & Global
