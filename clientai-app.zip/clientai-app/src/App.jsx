import { useState, useEffect } from "react";

// ── CONSTANTS ─────────────────────────────────────────────────
const LANGUAGES = [
  {code:"English",flag:"🇬🇧"},{code:"Thai",flag:"🇹🇭"},{code:"Hindi",flag:"🇮🇳"},
  {code:"Bengali",flag:"🇧🇩"},{code:"Spanish",flag:"🇪🇸"},{code:"French",flag:"🇫🇷"},
  {code:"Arabic",flag:"🇸🇦"},{code:"Portuguese",flag:"🇧🇷"},{code:"Indonesian",flag:"🇮🇩"},
  {code:"Japanese",flag:"🇯🇵"},{code:"Korean",flag:"🇰🇷"},{code:"Chinese",flag:"🇨🇳"},
  {code:"Russian",flag:"🇷🇺"},{code:"German",flag:"🇩🇪"},{code:"Vietnamese",flag:"🇻🇳"},
  {code:"Italian",flag:"🇮🇹"},{code:"Turkish",flag:"🇹🇷"},{code:"Malay",flag:"🇲🇾"},
  {code:"Tagalog",flag:"🇵🇭"},{code:"Urdu",flag:"🇵🇰"},{code:"Swahili",flag:"🇰🇪"},
  {code:"Dutch",flag:"🇳🇱"},{code:"Polish",flag:"🇵🇱"},{code:"Greek",flag:"🇬🇷"},
];

const industries = ["Restaurant / Food","Retail / Shop","Beauty / Salon","Fitness / Gym","Real Estate","Coaching / Consulting","Tech / SaaS","Healthcare","Education","Creative / Agency","Other"];
const services   = ["Website Design","Social Media Management","SEO","Logo & Branding","Video / Reels","Photography","Copywriting","Ads / Marketing","App Development","E-commerce Setup"];
const statusColors = {"Not Contacted":"#6b7280","Contacted":"#1d4ed8","Interested":"#b45309","Proposal Sent":"#7c3aed","Won ✅":"#15803d","Lost ❌":"#b91c1c"};

const PLANS = [
  {id:"free",  name:"Free",   usd:0,   inr:0,    color:"#6b7280", features:["3 strategies/month","WhatsApp & email messages","Client tracker (10 clients)","5 languages","Dark/Light mode"]},
  {id:"pro",   name:"Pro",    usd:9,   inr:299,  color:"#7c3aed", badge:"Most Popular", features:["Unlimited strategies","All 10 AI tools","24 languages","Invoice & proposal builder","Unlimited clients","Strategy history","Priority AI"]},
  {id:"agency",name:"Agency", usd:29,  inr:999,  color:"#1d4ed8", features:["Everything in Pro","5 team members","White-label reports","Custom branding","Priority support"]},
  {id:"enterprise",name:"Enterprise",usd:99,inr:2999,color:"#065f46",badge:"For Teams",features:["Everything in Agency","Unlimited team members","Dedicated account manager","Custom integrations","API access","SLA support"]},
];

const D = {
  bg:"#0f0f13",sb:"#161620",hd:"#161620",cd:"#1e1e2a",br:"#2a2a38",
  in:"#1a1a26",ib:"#2e2e3e",tx:"#f0f0f5",su:"#6b6b80",mi:"#a0a0b5",
  ac:"#7c3aed",al:"rgba(124,58,237,0.1)",ab:"rgba(124,58,237,0.3)",
  gn:"#15803d",gnb:"rgba(21,128,61,0.1)",rd:"#b91c1c",rdb:"rgba(185,28,28,0.08)",
};
const L = {
  bg:"#f4f4f8",sb:"#ffffff",hd:"#ffffff",cd:"#ffffff",br:"#e4e4ec",
  in:"#f8f8fc",ib:"#d8d8e8",tx:"#111118",su:"#8888a0",mi:"#444458",
  ac:"#7c3aed",al:"rgba(124,58,237,0.07)",ab:"rgba(124,58,237,0.2)",
  gn:"#15803d",gnb:"rgba(21,128,61,0.07)",rd:"#b91c1c",rdb:"rgba(185,28,28,0.06)",
};

const DEMO = {name:"Demo User",email:"demo@clientai.com",password:"demo1234",phone:"+1 234 567 8900",country:"USA",businessName:"Demo Studio",plan:"pro",joined:"Jan 2026"};

// ── AI CALL ───────────────────────────────────────────────────
async function callAI(prompt, maxTokens = 1400) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: maxTokens,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  if (!res.ok) throw new Error(`API error ${res.status}`);
  const data = await res.json();
  return data.content?.map(b => b.text || "").join("\n") || "No response.";
}

// ── HELPERS ───────────────────────────────────────────────────
function Avatar({ name = "?", size = 32 }) {
  const i = (name || "?").split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  const hue = (name || "").charCodeAt(0) * 37 % 360;
  return <div style={{ width: size, height: size, borderRadius: "50%", background: `hsl(${hue},55%,45%)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.36, fontWeight: 700, color: "#fff", flexShrink: 0 }}>{i}</div>;
}

function Badge({ label, color = "#7c3aed" }) {
  return <span style={{ background: `${color}18`, color, border: `1px solid ${color}30`, borderRadius: 4, padding: "2px 8px", fontSize: 11, fontWeight: 600 }}>{label}</span>;
}

function OTPInput({ value, onChange }) {
  const vals = value.split("").concat(Array(6).fill("")).slice(0, 6);
  const handleKey = (i, e) => {
    if (e.key === "Backspace") { const n = vals.slice(); n[i] = ""; onChange(n.join("")); if (i > 0) document.getElementById(`otp-${i-1}`)?.focus(); }
    else if (/^\d$/.test(e.key)) { const n = vals.slice(); n[i] = e.key; onChange(n.join("")); if (i < 5) document.getElementById(`otp-${i+1}`)?.focus(); }
  };
  return (
    <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
      {vals.map((v, i) => <input key={i} id={`otp-${i}`} value={v} maxLength={1} onChange={() => {}} onKeyDown={e => handleKey(i, e)} style={{ width: 44, height: 50, borderRadius: 8, border: `1.5px solid ${v ? "#7c3aed" : "#2e2e3e"}`, background: v ? "rgba(124,58,237,0.1)" : "#1a1a26", color: "#f0f0f5", fontSize: 22, fontWeight: 700, textAlign: "center", outline: "none", fontFamily: "inherit" }} />)}
    </div>
  );
}

// ── TOAST ─────────────────────────────────────────────────────
function Toast({ msg, onDone }) {
  useEffect(() => { const t = setTimeout(onDone, 2200); return () => clearTimeout(t); }, []);
  return (
    <div style={{ position: "fixed", bottom: 80, left: "50%", transform: "translateX(-50%)", background: "#1e1e2a", border: "1px solid #2a2a38", borderRadius: 10, padding: "10px 20px", fontSize: 13, fontWeight: 600, color: "#f0f0f5", zIndex: 9999, boxShadow: "0 8px 24px rgba(0,0,0,0.4)", display: "flex", alignItems: "center", gap: 8, whiteSpace: "nowrap" }}>
      <span style={{ color: "#4ade80", fontSize: 15 }}>✓</span> {msg}
    </div>
  );
}
export default function App() {
  const [dark, setDark] = useState(true);
  const T = dark ? D : L;
  const [toast, setToast] = useState(null);
  const showToast = (msg) => setToast(msg);

  // Views: landing | auth | app
  const [view, setView] = useState("landing");
  const [user, setUser] = useState(null);
  const [savedUsers, setSavedUsers] = useState([DEMO]);

  // Auth
  const [authTab, setAuthTab] = useState("login");
  const [authStep, setAuthStep] = useState(1);
  const [otp, setOtp] = useState("");
  const [otpTimer, setOtpTimer] = useState(0);
  const [showPass, setShowPass] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [authErr, setAuthErr] = useState({});
  const [sf, setSf] = useState({ name:"",email:"",password:"",confirm:"",phone:"",country:"",biz:"" });
  const [lf, setLf] = useState({ email:"", password:"" });

  // App
  const [tool, setTool] = useState("dashboard");
  const [lang, setLang] = useState("English");
  const [showLang, setShowLang] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [sidebar, setSidebar] = useState(true);
  const [copied, setCopied] = useState(null);
  const [billing, setBilling] = useState("monthly");
  const [payCurrency, setPayCurrency] = useState("usd");
  const [editProfile, setEditProfile] = useState(false);
  const [pf, setPf] = useState({});

  // Strategy Generator
  const [gs, setGs] = useState(0); // step 0,1,2
  const [gf, setGf] = useState({ name:"",company:"",phone:"",email:"",industry:"",budget:"",offering:[],notWanting:[],targetLocation:"",targetIndustry:"",goal:"" });
  const [gResult, setGResult] = useState(null);
  const [gLoading, setGLoading] = useState(false);
  const [gErr, setGErr] = useState("");
  const [gTab, setGTab] = useState("strategy");
  const [gParsed, setGParsed] = useState({ whatsapp:[], emails:[] });

  // Other tools
  const [history, setHistory] = useState([]);
  const [viewHist, setViewHist] = useState(null);
  const [clients, setClients] = useState([]);
  const [newCl, setNewCl] = useState({ name:"",company:"",contact:"",status:"Not Contacted",notes:"" });
  const [showAddCl, setShowAddCl] = useState(false);
  const [sf2, setSf2] = useState({ business:"",niche:"",platform:"Instagram",goal:"Get more clients",tone:"Professional" });
  const [sr, setSr] = useState(null); const [sl, setSl] = useState(false);
  const [pf2, setPf2] = useState({ service:"Website Design",hours:"10",experience:"Intermediate",location:"",type:"One-time" });
  const [pr, setPr] = useState(null); const [pl, setPl] = useState(false);
  const [inf, setInf] = useState({ yourName:"",yourEmail:"",clientName:"",clientEmail:"",service:"",amount:"",currency:"USD",dueDate:"",notes:"" });
  const [ir, setIr] = useState(null); const [il, setIl] = useState(false);
  const [prpf, setPrpf] = useState({ yourName:"",company:"",clientName:"",clientBiz:"",service:"",budget:"",timeline:"",problem:"" });
  const [prpr, setPrpr] = useState(null); const [prpl, setPrpl] = useState(false);
  const [fus, setFus] = useState([]); const [newFu, setNewFu] = useState({ clientName:"",company:"",contact:"",last:"",date:"",reason:"Follow up on proposal",notes:"" });
  const [showFu, setShowFu] = useState(false); const [fuMsg, setFuMsg] = useState(null); const [fuL, setFuL] = useState(false); const [selFu, setSelFu] = useState(null);
  const [nf, setNf] = useState({ industry:"",style:"Modern",keywords:"",market:"" }); const [nr, setNr] = useState(null); const [nl, setNl] = useState(false);
  const [cf, setCf] = useState({ service:"",location:"",competitor:"" }); const [cr, setCr] = useState(null); const [cl2, setCl2] = useState(false);

  // OTP timer
  useEffect(() => { if (otpTimer > 0) { const t = setTimeout(() => setOtpTimer(v => v-1), 1000); return () => clearTimeout(t); } }, [otpTimer]);

  // ── AUTH HANDLERS ─────────────────────────────────────────
  const login = async () => {
    const e = {};
    if (!lf.email.includes("@")) e.email = "Valid email required";
    if (!lf.password) e.pass = "Password required";
    setAuthErr(e); if (Object.keys(e).length) return;
    setAuthLoading(true); await new Promise(r => setTimeout(r, 700));
    const found = savedUsers.find(u => u.email === lf.email && u.password === lf.password);
    if (found) { setUser(found); setView("app"); setAuthErr({}); }
    else setAuthErr({ login: "Incorrect credentials. Try demo@clientai.com / demo1234" });
    setAuthLoading(false);
  };

  const sendOTP = async () => {
    const e = {};
    if (!sf.name.trim()) e.name = "Required";
    if (!sf.email.includes("@")) e.email = "Valid email required";
    if (sf.password.length < 8) e.pass = "Min 8 characters";
    if (sf.password !== sf.confirm) e.conf = "Passwords don't match";
    setAuthErr(e); if (Object.keys(e).length) return;
    setAuthLoading(true); await new Promise(r => setTimeout(r, 800));
    setOtpTimer(60); setAuthStep(3); setAuthLoading(false);
  };

  const verifyOTP = async () => {
    if (otp.length < 6) { setAuthErr({ otp: "Enter the 6-digit code" }); return; }
    setAuthLoading(true); await new Promise(r => setTimeout(r, 700));
    const nu = { name:sf.name, email:sf.email, password:sf.password, phone:sf.phone, country:sf.country, businessName:sf.biz, plan:"free", joined: new Date().toLocaleDateString("en-US",{month:"short",year:"numeric"}) };
    setSavedUsers(u => [...u, nu]); setUser(nu); setView("app"); setAuthLoading(false);
  };

  const googleAuth = async () => {
    setAuthLoading(true); await new Promise(r => setTimeout(r, 1000));
    const gu = { name:"Google User", email:"googleuser@gmail.com", phone:"", country:"", businessName:"", plan:"free", joined: new Date().toLocaleDateString("en-US",{month:"short",year:"numeric"}) };
    setUser(gu); setView("app"); setAuthLoading(false);
  };

  const logout = () => { setUser(null); setView("landing"); setLf({email:"",password:""}); setSf({name:"",email:"",password:"",confirm:"",phone:"",country:"",biz:""}); setOtp(""); setAuthStep(1); setShowMenu(false); };

  // ── STRATEGY GENERATOR ────────────────────────────────────
  const parseStrategy = (text) => {
    const lines = text.split("\n");
    const whatsapp = [], emails = [];
    let mode = null, cur = null;
    for (const raw of lines) {
      const line = raw.replace(/\*\*/g, "").trim();
      if (!line) continue;
      if (/whatsapp|outreach message|message [abc]|top 3 outreach/i.test(line)) { mode = "wa"; continue; }
      if (/email template|email subject/i.test(line)) { mode = "em"; continue; }
      if (/ideal client|best platform|weekly action|strategic insight|power tip/i.test(line)) { mode = null; }
      if (mode === "wa") {
        if (/^message [abc]/i.test(line)) { if (cur) whatsapp.push(cur); cur = { label: line, body: [] }; }
        else if (cur) cur.body.push(line);
        else whatsapp.push({ label: "Message", body: [line] });
      } else if (mode === "em") {
        if (/^subject:/i.test(line)) { if (cur) emails.push(cur); cur = { subject: line.replace(/^subject:\s*/i, ""), body: [] }; }
        else if (cur) cur.body.push(line);
      }
    }
    if (cur && mode === "wa") whatsapp.push(cur);
    if (cur && mode === "em") emails.push(cur);
    return { whatsapp, emails };
  };

  const generateStrategy = async () => {
    setGLoading(true); setGs(2); setGResult(null); setGErr(""); setGParsed({ whatsapp:[], emails:[] });
    try {
      const prompt = `You are a senior business development consultant. A business owner has filled out this profile:

OWNER NAME: ${gf.name}
COMPANY: ${gf.company}
PHONE: ${gf.phone}
EMAIL: ${gf.email || "N/A"}
INDUSTRY: ${gf.industry}
MONTHLY BUDGET: ${gf.budget || "Not specified"}
SERVICES OFFERED: ${gf.offering.length ? gf.offering.join(", ") : "Not specified"}
SERVICES NOT OFFERED: ${gf.notWanting.length ? gf.notWanting.join(", ") : "None"}
TARGET CLIENT LOCATION: ${gf.targetLocation}
TARGET CLIENT INDUSTRY: ${gf.targetIndustry}
BUSINESS GOAL: ${gf.goal || "Acquire new clients"}

Write the ENTIRE response in ${lang} language.

Produce a complete, actionable client acquisition strategy with these exact sections:

1. IDEAL CLIENT PROFILE
Describe the perfect client in 3 precise sentences. Be specific about who they are, what they need, and why they need it now.

2. TOP 3 OUTREACH MESSAGES
Write 3 ready-to-send WhatsApp/DM messages. Each must be under 60 words, warm, direct, and not salesy. Include the owner's name and company naturally.
Format exactly as:
Message A: [message text]
Message B: [message text]
Message C: [message text]

3. EMAIL TEMPLATES
Write 2 professional cold email templates.
Format exactly as:
Subject: [subject line]
[email body — under 100 words, professional and warm]

Subject: [subject line]
[email body — under 100 words, professional and warm]

4. BEST PLATFORMS TO FIND CLIENTS
List 4 specific platforms with one concrete, actionable tip for each.

5. WEEKLY ACTION PLAN
A specific task for each day, Monday to Friday. Each task must be concrete and measurable.

6. STRATEGIC INSIGHT
One high-impact, unconventional approach that most competitors in this space are overlooking.

Write in plain text only. No markdown symbols or bullet characters. Be specific, practical, and professional throughout. Write entirely in ${lang}.`;

      const text = await callAI(prompt, 1500);
      setGResult(text);
      const parsed = parseStrategy(text);
      setGParsed(parsed);
      setHistory(h => [{
        id: Date.now(),
        date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
        company: gf.company, name: gf.name, lang,
        targetIndustry: gf.targetIndustry, targetLocation: gf.targetLocation,
        text
      }, ...h.slice(0, 29)]);
    } catch (err) {
      setGErr("Failed to generate strategy. Please check your connection and try again.");
    }
    setGLoading(false);
  };

  const runAI = async (prompt, setter, loadSetter, max = 1000) => {
    loadSetter(true); setter(null);
    try { setter(await callAI(prompt, max)); }
    catch { setter("Error generating. Please try again."); }
    loadSetter(false);
  };

  // ── COPY / DOWNLOAD ───────────────────────────────────────
  const copy = (text, id) => { navigator.clipboard.writeText(text); setCopied(id); setTimeout(() => setCopied(null), 2000); showToast("Copied to clipboard!"); };
  const download = (text, name) => { const b = new Blob([text], { type: "text/plain" }); const u = URL.createObjectURL(b); const a = document.createElement("a"); a.href = u; a.download = name; a.click(); URL.revokeObjectURL(u); showToast(`Downloaded ${name}`); };
  const openWA = t => window.open(`https://wa.me/?text=${encodeURIComponent(t)}`, "_blank");
  const openMail = (s, b) => window.open(`mailto:?subject=${encodeURIComponent(s)}&body=${encodeURIComponent(b)}`, "_blank");

  const toggleOffer = (field, val) => setGf(f => ({ ...f, [field]: f[field].includes(val) ? f[field].filter(x => x !== val) : [...f[field], val] }));

  // ── SHARED COMPONENTS ─────────────────────────────────────
  const planColor = { free:"#6b7280", pro:"#7c3aed", agency:"#1d4ed8" };
  const planLabel = { free:"Free Plan", pro:"Pro Plan", agency:"Agency Plan" };

  const F = ({ label, children, mb = 14 }) => <div style={{ marginBottom: mb }}><label style={{ display: "block", fontSize: 11, fontWeight: 700, color: T.su, marginBottom: 5, textTransform: "uppercase", letterSpacing: "0.5px" }}>{label}</label>{children}</div>;
  const I = ({ value, onChange, placeholder, type = "text", onKeyDown }) => <input type={type} value={value} placeholder={placeholder} onChange={onChange} onKeyDown={onKeyDown} style={{ width: "100%", padding: "9px 12px", borderRadius: 7, border: `1px solid ${T.ib}`, background: T.in, color: T.tx, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit" }} />;
  const Sel = ({ value, onChange, options }) => <select value={value} onChange={onChange} style={{ width: "100%", padding: "9px 12px", borderRadius: 7, border: `1px solid ${T.ib}`, background: T.in, color: T.tx, fontSize: 14, outline: "none", boxSizing: "border-box" }}>{options.map(o => <option key={o} value={o}>{o}</option>)}</select>;
  const TA = ({ value, onChange, placeholder, rows = 3 }) => <textarea value={value} onChange={onChange} placeholder={placeholder} rows={rows} style={{ width: "100%", padding: "9px 12px", borderRadius: 7, border: `1px solid ${T.ib}`, background: T.in, color: T.tx, fontSize: 14, outline: "none", boxSizing: "border-box", resize: "vertical", fontFamily: "inherit", lineHeight: 1.6 }} />;
  const Btn = ({ label, onClick, disabled, variant = "primary", size = "md", full }) => {
    const bg = variant === "primary" ? "#7c3aed" : variant === "danger" ? "#b91c1c" : T.cd;
    const co = variant === "primary" || variant === "danger" ? "#fff" : T.mi;
    const bd = variant === "secondary" ? `1px solid ${T.br}` : "none";
    const pd = size === "sm" ? "6px 12px" : size === "lg" ? "12px 22px" : "9px 16px";
    return <button onClick={onClick} disabled={disabled} style={{ padding: pd, borderRadius: 7, border: bd, background: disabled ? T.cd : bg, color: disabled ? T.su : co, fontSize: size === "sm" ? 12 : 14, fontWeight: 600, cursor: disabled ? "not-allowed" : "pointer", width: full ? "100%" : "auto", opacity: disabled ? 0.55 : 1, letterSpacing: "0.1px", transition: "opacity 0.15s" }}>{label}</button>;
  };
  const Card = ({ children, extra = {} }) => <div style={{ background: T.cd, border: `1px solid ${T.br}`, borderRadius: 10, padding: 20, marginBottom: 14, ...extra }}>{children}</div>;
  const Hr = () => <div style={{ height: 1, background: T.br, margin: "14px 0" }} />;
  const ResultBox = ({ text, id, filename }) => text ? (
    <Card>
      <pre style={{ whiteSpace: "pre-wrap", fontSize: 13.5, color: T.mi, lineHeight: 1.9, margin: "0 0 14px", fontFamily: "'Georgia',serif" }}>{text}</pre>
      <div style={{ display: "flex", gap: 8 }}>
        <Btn label={copied === id ? "Copied!" : "Copy"} onClick={() => copy(text, id)} variant="secondary" size="sm" />
        {filename && <Btn label="Download" onClick={() => download(text, filename)} variant="secondary" size="sm" />}
      </div>
    </Card>
  ) : null;
  const PillSel = ({ options, value, onChange, color = "#7c3aed" }) => <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>{options.map(o => <button key={o} onClick={() => onChange(o)} style={{ padding: "5px 11px", borderRadius: 5, border: `1px solid ${value === o ? color : T.br}`, background: value === o ? `${color}15` : T.in, color: value === o ? color : T.mi, fontSize: 13, cursor: "pointer", fontWeight: value === o ? 600 : 400 }}>{o}</button>)}</div>;
  const MultiPill = ({ options, value, onChange, color = "#7c3aed" }) => <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>{options.map(o => <button key={o} onClick={() => onChange(o)} style={{ padding: "5px 11px", borderRadius: 5, border: `1px solid ${value.includes(o) ? color : T.br}`, background: value.includes(o) ? `${color}15` : T.in, color: value.includes(o) ? color : T.mi, fontSize: 13, cursor: "pointer", fontWeight: value.includes(o) ? 600 : 400 }}>{o}</button>)}</div>;
  const GoogleBtn = ({ label }) => <button onClick={googleAuth} disabled={authLoading} style={{ width: "100%", padding: "10px 16px", borderRadius: 7, border: `1px solid ${T.br}`, background: T.cd, color: T.tx, fontSize: 14, fontWeight: 500, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", gap: 10 }}><svg width="16" height="16" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.31-8.16 2.31-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>{authLoading ? "Connecting..." : label}</button>;

  // ═══════════════════════════════════════════════════════════
  // LANDING
  // ═══════════════════════════════════════════════════════════
  if (view === "landing") return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
    <div style={{ minHeight: "100vh", background: dark ? "#0a0a0f" : "#f4f4f8", fontFamily: "'Inter','Segoe UI',sans-serif", color: dark ? "#f0f0f5" : "#111118" }}>
      <nav style={{ borderBottom: `1px solid ${dark?"#1e1e28":"#e4e4ec"}`, padding: "14px 32px", display: "flex", alignItems: "center", justifyContent: "space-between", background: dark ? "#0f0f13" : "#fff", position: "sticky", top: 0, zIndex: 50 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
          <div style={{ width: 30, height: 30, borderRadius: 7, background: "#7c3aed", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, color: "#fff", fontWeight: 700 }}>C</div>
          <span style={{ fontWeight: 700, fontSize: 16, letterSpacing: "-0.3px" }}>ClientAI</span>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <button onClick={() => setDark(d => !d)} style={{ padding: "6px 10px", borderRadius: 6, background: "transparent", border: `1px solid ${dark?"#2a2a38":"#e4e4ec"}`, color: dark?"#a0a0b5":"#6b7280", cursor: "pointer", fontSize: 13 }}>{dark ? "Light" : "Dark"}</button>
          <button onClick={() => { setView("auth"); setAuthTab("login"); }} style={{ padding: "7px 16px", borderRadius: 6, border: `1px solid ${dark?"#2a2a38":"#d8d8e8"}`, background: "transparent", color: dark?"#a0a0b5":"#444458", cursor: "pointer", fontSize: 13, fontWeight: 500 }}>Log In</button>
          <button onClick={() => { setView("auth"); setAuthTab("signup"); }} style={{ padding: "7px 16px", borderRadius: 6, border: "none", background: "#7c3aed", color: "#fff", cursor: "pointer", fontSize: 13, fontWeight: 600 }}>Get Started Free</button>
        </div>
      </nav>
      <div style={{ maxWidth: 960, margin: "0 auto", padding: "80px 24px 60px", textAlign: "center" }}>
        <div style={{ display: "inline-block", background: dark?"#1e1e2a":"#f0eeff", border: `1px solid ${dark?"#2a2a38":"#ddd8f8"}`, borderRadius: 5, padding: "4px 12px", fontSize: 12, color: "#7c3aed", fontWeight: 600, marginBottom: 24, letterSpacing: "0.5px", textTransform: "uppercase" }}>AI-Powered Client Acquisition Platform</div>
        <h1 style={{ fontSize: "clamp(32px,6vw,58px)", fontWeight: 800, lineHeight: 1.1, letterSpacing: "-2px", margin: "0 0 20px" }}>Acquire clients faster<br />with <span style={{ color: "#7c3aed" }}>AI built for business</span></h1>
        <p style={{ fontSize: "clamp(15px,2vw,18px)", color: dark?"#6b6b80":"#8888a0", maxWidth: 520, margin: "0 auto 36px", lineHeight: 1.7 }}>Strategy generation, client tracking, invoices, proposals, and outreach — all powered by AI, in 24 languages.</p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", marginBottom: 60 }}>
          <button onClick={() => { setView("auth"); setAuthTab("signup"); }} style={{ padding: "12px 28px", borderRadius: 7, border: "none", background: "#7c3aed", color: "#fff", fontSize: 15, fontWeight: 600, cursor: "pointer" }}>Start Free — No Card Required</button>
          <button onClick={() => { setView("auth"); setAuthTab("login"); }} style={{ padding: "12px 28px", borderRadius: 7, border: `1px solid ${dark?"#2a2a38":"#d8d8e8"}`, background: "transparent", color: dark?"#a0a0b5":"#444458", fontSize: 15, fontWeight: 500, cursor: "pointer" }}>Log In</button>
        </div>
        <div style={{ display: "flex", borderTop: `1px solid ${dark?"#1e1e28":"#e4e4ec"}`, borderBottom: `1px solid ${dark?"#1e1e28":"#e4e4ec"}`, padding: "24px 0", marginBottom: 60, flexWrap: "wrap" }}>
          {[["10","AI Tools"],["24","Languages"],["4","Payment Methods"],["Free","To Start"]].map(([n,l],i,a) => <div key={l} style={{ flex: "1 1 120px", textAlign: "center", padding: "0 24px", borderRight: i < a.length-1 ? `1px solid ${dark?"#1e1e28":"#e4e4ec"}` : "none" }}><div style={{ fontSize: 28, fontWeight: 800, color: "#7c3aed" }}>{n}</div><div style={{ fontSize: 12, color: dark?"#6b6b80":"#8888a0" }}>{l}</div></div>)}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(200px,1fr))", gap: 12, textAlign: "left" }}>
          {[["Strategy Generator","Build a complete client acquisition plan with outreach messages and a weekly action plan."],["Client Tracker","Track every lead from contact to closed deal with status management."],["Invoice Generator","Create professional invoices instantly. Copy or download."],["Proposal Builder","Win more projects with AI-written proposals for each client."],["Social Media Posts","Platform-ready captions and hashtags for any platform."],["Pricing Calculator","Find the right price based on your experience and market."],["Follow-up Manager","Schedule follow-ups and let AI write the messages."],["Business Name AI","Generate professional names with meanings and taglines."],["Competitor Analysis","Identify opportunities your competitors are missing."],["Strategy History","Every strategy saved automatically for reference."]].map(([name, desc]) => (
            <div key={name} style={{ background: dark?"#161620":"#fff", border: `1px solid ${dark?"#2a2a38":"#e4e4ec"}`, borderRadius: 9, padding: 18, cursor: "pointer" }} onClick={() => { setView("auth"); setAuthTab("signup"); }}>
              <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 5 }}>{name}</div>
              <div style={{ fontSize: 12.5, color: dark?"#6b6b80":"#8888a0", lineHeight: 1.6 }}>{desc}</div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 60, padding: "40px 32px", background: dark?"#161620":"#fff", border: `1px solid ${dark?"#2a2a38":"#e4e4ec"}`, borderRadius: 12, textAlign: "center" }}>
          <h2 style={{ fontSize: "clamp(20px,3vw,30px)", fontWeight: 700, margin: "0 0 10px", letterSpacing: "-0.5px" }}>Ready to grow your client base?</h2>
          <p style={{ color: dark?"#6b6b80":"#8888a0", fontSize: 14, marginBottom: 24 }}>Create your free account and start generating clients today.</p>
          <button onClick={() => { setView("auth"); setAuthTab("signup"); }} style={{ padding: "12px 28px", borderRadius: 7, border: "none", background: "#7c3aed", color: "#fff", fontSize: 14, fontWeight: 600, cursor: "pointer" }}>Create Free Account</button>
          <p style={{ color: dark?"#3a3a50":"#c0c0d0", fontSize: 12, marginTop: 12 }}>Free forever · No credit card · 24 languages</p>
        </div>
      </div>
    </div>
    </>
  );

  // ═══════════════════════════════════════════════════════════
  // AUTH
  // ═══════════════════════════════════════════════════════════
  if (view === "auth") return (
    <>
      {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
    <div style={{ minHeight: "100vh", background: dark?"#0a0a0f":"#f4f4f8", display: "flex", flexDirection: "column", fontFamily: "'Inter','Segoe UI',sans-serif", color: T.tx }}>
      <div style={{ padding: "15px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: `1px solid ${T.br}`, background: T.hd }}>
        <button onClick={() => setView("landing")} style={{ display: "flex", alignItems: "center", gap: 8, background: "none", border: "none", cursor: "pointer", color: T.tx }}>
          <div style={{ width: 28, height: 28, borderRadius: 6, background: "#7c3aed", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, color: "#fff", fontWeight: 700 }}>C</div>
          <span style={{ fontWeight: 700, fontSize: 15 }}>ClientAI</span>
        </button>
        <button onClick={() => setDark(d => !d)} style={{ padding: "5px 10px", borderRadius: 6, background: "transparent", border: `1px solid ${T.br}`, color: T.su, cursor: "pointer", fontSize: 12 }}>{dark ? "Light" : "Dark"}</button>
      </div>
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", padding: "32px 16px" }}>
        <div style={{ width: "100%", maxWidth: 400 }}>
          <div style={{ display: "flex", background: T.cd, border: `1px solid ${T.br}`, borderRadius: 8, padding: 4, marginBottom: 20 }}>
            {["signup","login"].map(tab => <button key={tab} onClick={() => { setAuthTab(tab); setAuthErr({}); setAuthStep(1); setOtp(""); }} style={{ flex: 1, padding: "9px", borderRadius: 6, border: "none", background: authTab === tab ? "#7c3aed" : "transparent", color: authTab === tab ? "#fff" : T.su, fontWeight: 600, fontSize: 13, cursor: "pointer" }}>{tab === "signup" ? "Create Account" : "Log In"}</button>)}
          </div>

          {/* OTP */}
          {authTab === "signup" && authStep === 3 && (
            <div>
              <Card>
                <div style={{ textAlign: "center", marginBottom: 18 }}>
                  <div style={{ fontSize: 14, fontWeight: 600, color: T.tx, marginBottom: 4 }}>Verify your email</div>
                  <p style={{ fontSize: 13, color: T.su, margin: "0 0 6px" }}>Enter the code sent to <strong style={{ color: T.tx }}>{sf.email}</strong></p>
                  <p style={{ fontSize: 12, color: "#7c3aed", margin: 0 }}>Use any 6 digits to demo (e.g. 1 2 3 4 5 6)</p>
                </div>
                <OTPInput value={otp} onChange={setOtp} />
                {authErr.otp && <p style={{ fontSize: 11, color: T.rd, textAlign: "center", marginTop: 8 }}>{authErr.otp}</p>}
                <div style={{ textAlign: "center", marginTop: 12 }}>
                  {otpTimer > 0 ? <p style={{ fontSize: 12, color: T.su }}>Resend in {otpTimer}s</p> : <button onClick={() => setOtpTimer(60)} style={{ background: "none", border: "none", color: "#7c3aed", fontSize: 12, cursor: "pointer", fontWeight: 600 }}>Resend Code</button>}
                </div>
              </Card>
              <Btn label={authLoading ? "Verifying..." : "Verify & Create Account"} onClick={verifyOTP} disabled={authLoading || otp.length < 6} variant="primary" full />
              <button onClick={() => { setAuthStep(2); setOtp(""); }} style={{ background: "none", border: "none", color: T.su, fontSize: 12, cursor: "pointer", marginTop: 10, display: "block", width: "100%", textAlign: "center" }}>← Back</button>
            </div>
          )}

          {/* Sign Up Step 1 */}
          {authTab === "signup" && authStep === 1 && (
            <div>
              <div style={{ textAlign: "center", marginBottom: 18 }}><h2 style={{ fontSize: 20, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Create your account</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>Free forever · No credit card needed</p></div>
              <GoogleBtn label="Sign up with Google" />
              <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "14px 0" }}><div style={{ flex: 1, height: 1, background: T.br }} /><span style={{ fontSize: 12, color: T.su }}>or</span><div style={{ flex: 1, height: 1, background: T.br }} /></div>
              <Card>
                <F label="Full Name"><I value={sf.name} onChange={e => { setSf(f => ({...f,name:e.target.value})); setAuthErr(er => ({...er,name:""})); }} placeholder="Your full name" /></F>
                {authErr.name && <p style={{ fontSize: 11, color: T.rd, marginTop: -10, marginBottom: 10 }}>{authErr.name}</p>}
                <F label="Email Address"><I value={sf.email} onChange={e => { setSf(f => ({...f,email:e.target.value})); setAuthErr(er => ({...er,email:""})); }} placeholder="you@example.com" /></F>
                {authErr.email && <p style={{ fontSize: 11, color: T.rd, marginTop: -10, marginBottom: 10 }}>{authErr.email}</p>}
                <F label="Password">
                  <div style={{ position: "relative" }}><I value={sf.password} onChange={e => { setSf(f => ({...f,password:e.target.value})); setAuthErr(er => ({...er,pass:""})); }} placeholder="Minimum 8 characters" type={showPass?"text":"password"} /><button type="button" onClick={() => setShowPass(v => !v)} style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: T.su, fontSize: 12 }}>{showPass?"Hide":"Show"}</button></div>
                </F>
                {authErr.pass && <p style={{ fontSize: 11, color: T.rd, marginTop: -10, marginBottom: 10 }}>{authErr.pass}</p>}
                <F label="Confirm Password" mb={0}>
                  <div style={{ position: "relative" }}><I value={sf.confirm} onChange={e => { setSf(f => ({...f,confirm:e.target.value})); setAuthErr(er => ({...er,conf:""})); }} placeholder="Repeat password" type={showPass?"text":"password"} /></div>
                </F>
                {authErr.conf && <p style={{ fontSize: 11, color: T.rd, marginTop: 4 }}>{authErr.conf}</p>}
              </Card>
              <Btn label="Next: Business Details →" onClick={() => { const e={}; if(!sf.name.trim())e.name="Required"; if(!sf.email.includes("@"))e.email="Valid email"; if(sf.password.length<8)e.pass="Min 8 chars"; if(sf.password!==sf.confirm)e.conf="Doesn't match"; setAuthErr(e); if(!Object.keys(e).length)setAuthStep(2); }} variant="primary" full />
              <p style={{ textAlign: "center", fontSize: 12, color: T.su, marginTop: 12 }}>Have an account? <button onClick={() => { setAuthTab("login"); setAuthErr({}); }} style={{ background: "none", border: "none", color: "#7c3aed", cursor: "pointer", fontWeight: 600, fontSize: 12 }}>Log in</button></p>
            </div>
          )}

          {/* Sign Up Step 2 */}
          {authTab === "signup" && authStep === 2 && (
            <div>
              <div style={{ textAlign: "center", marginBottom: 18 }}><h2 style={{ fontSize: 20, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Business details</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>Optional — complete later in your profile</p></div>
              <Card>
                <F label="Business / Company Name"><I value={sf.biz} onChange={e => setSf(f => ({...f,biz:e.target.value}))} placeholder="Your business name" /></F>
                <F label="Phone / WhatsApp"><I value={sf.phone} onChange={e => setSf(f => ({...f,phone:e.target.value}))} placeholder="+1 234 567 8900" /></F>
                <F label="Country" mb={0}><Sel value={sf.country} onChange={e => setSf(f => ({...f,country:e.target.value}))} options={["","Thailand","India","Bangladesh","USA","UK","Singapore","Malaysia","Indonesia","Vietnam","Philippines","Japan","South Korea","China","Germany","France","UAE","Australia","Canada","Brazil","Kenya","Other"]} /></F>
              </Card>
              <div style={{ display: "flex", gap: 9 }}>
                <Btn label="← Back" onClick={() => setAuthStep(1)} variant="secondary" />
                <div style={{ flex: 1 }}><Btn label={authLoading ? "Sending code..." : "Send Verification Code"} onClick={sendOTP} disabled={authLoading} variant="primary" full /></div>
              </div>
            </div>
          )}

          {/* Login */}
          {authTab === "login" && (
            <div>
              <div style={{ textAlign: "center", marginBottom: 18 }}><h2 style={{ fontSize: 20, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Welcome back</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>Log in to your ClientAI account</p></div>
              <GoogleBtn label="Continue with Google" />
              <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "14px 0" }}><div style={{ flex: 1, height: 1, background: T.br }} /><span style={{ fontSize: 12, color: T.su }}>or</span><div style={{ flex: 1, height: 1, background: T.br }} /></div>
              <Card>
                <F label="Email Address"><I value={lf.email} onChange={e => { setLf(f => ({...f,email:e.target.value})); setAuthErr(er => ({...er,email:""})); }} placeholder="you@example.com" onKeyDown={e => e.key==="Enter"&&login()} /></F>
                {authErr.email && <p style={{ fontSize: 11, color: T.rd, marginTop: -10, marginBottom: 10 }}>{authErr.email}</p>}
                <F label="Password" mb={4}>
                  <div style={{ position: "relative" }}><I value={lf.password} onChange={e => { setLf(f => ({...f,password:e.target.value})); setAuthErr(er => ({...er,pass:""})); }} placeholder="Your password" type={showPass?"text":"password"} onKeyDown={e => e.key==="Enter"&&login()} /><button type="button" onClick={() => setShowPass(v => !v)} style={{ position: "absolute", right: 10, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", color: T.su, fontSize: 12 }}>{showPass?"Hide":"Show"}</button></div>
                </F>
                {authErr.pass && <p style={{ fontSize: 11, color: T.rd, marginBottom: 6 }}>{authErr.pass}</p>}
                <button style={{ background: "none", border: "none", color: "#7c3aed", fontSize: 12, cursor: "pointer", fontWeight: 500, padding: 0 }}>Forgot password?</button>
                {authErr.login && <div style={{ background: T.rdb, border: `1px solid ${T.rd}30`, borderRadius: 6, padding: "9px 12px", fontSize: 12, color: T.rd, marginTop: 10 }}>{authErr.login}</div>}
              </Card>
              <Btn label={authLoading ? "Logging in..." : "Log In"} onClick={login} disabled={authLoading} variant="primary" full />
              <div style={{ background: T.cd, border: `1px solid ${T.br}`, borderRadius: 7, padding: "10px 14px", marginTop: 10, textAlign: "center" }}>
                <p style={{ fontSize: 12, color: T.su, margin: "0 0 3px" }}>Demo account</p>
                <p style={{ fontSize: 13, margin: 0 }}><strong style={{ color: "#7c3aed" }}>demo@clientai.com</strong> / <strong style={{ color: "#7c3aed" }}>demo1234</strong></p>
              </div>
              <p style={{ textAlign: "center", fontSize: 12, color: T.su, marginTop: 12 }}>No account? <button onClick={() => { setAuthTab("signup"); setAuthErr({}); }} style={{ background: "none", border: "none", color: "#7c3aed", cursor: "pointer", fontWeight: 600, fontSize: 12 }}>Create one free</button></p>
            </div>
          )}
        </div>
      </div>
    </div>
    </>
  );

  // ═══════════════════════════════════════════════════════════
  // MAIN APP
  // ═══════════════════════════════════════════════════════════
  if (view === "app" && user) {
    const NAVTOOLS = [
      {id:"dashboard",label:"Dashboard"},{id:"generate",label:"Strategy"},
      {id:"tracker",label:"Clients"},{id:"history",label:"History"},
      {id:"social",label:"Social Posts"},{id:"pricing",label:"Pricing"},
      {id:"invoice",label:"Invoice"},{id:"proposal",label:"Proposal"},
      {id:"followup",label:"Follow-up"},{id:"naming",label:"Names"},
      {id:"competitor",label:"Competitor"},{id:"upgrade",label:"Upgrade"},
      {id:"profile",label:"Profile"},{id:"settings",label:"Settings"},
    ];

    return (
      <>
        {toast && <Toast msg={toast} onDone={() => setToast(null)} />}
      <div style={{ minHeight: "100vh", background: T.bg, fontFamily: "'Inter','Segoe UI',sans-serif", color: T.tx, display: "flex", flexDirection: "column" }}>

        {/* HEADER */}
        <header style={{ background: T.hd, borderBottom: `1px solid ${T.br}`, padding: "0 20px", height: 52, display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 100, flexShrink: 0 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <button onClick={() => setSidebar(v => !v)} style={{ background: "none", border: "none", cursor: "pointer", color: T.su, fontSize: 16, padding: "4px 6px" }}>☰</button>
            <div style={{ width: 26, height: 26, borderRadius: 6, background: "#7c3aed", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, color: "#fff", fontWeight: 700 }}>C</div>
            <span style={{ fontWeight: 700, fontSize: 14, letterSpacing: "-0.2px" }}>ClientAI</span>
            <Badge label={planLabel[user.plan||"free"]} color={planColor[user.plan||"free"]} />
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {/* Language */}
            <div style={{ position: "relative" }}>
              <button onClick={() => { setShowLang(v => !v); setShowMenu(false); }} style={{ display: "flex", alignItems: "center", gap: 4, padding: "5px 9px", borderRadius: 6, border: `1px solid ${T.br}`, background: T.cd, color: T.tx, cursor: "pointer", fontSize: 12, fontWeight: 500 }}>
                {LANGUAGES.find(l => l.code === lang)?.flag} {lang} <span style={{ fontSize: 9, opacity: 0.5 }}>▼</span>
              </button>
              {showLang && <div style={{ position: "absolute", right: 0, top: "calc(100% + 6px)", background: T.cd, border: `1px solid ${T.br}`, borderRadius: 8, padding: 6, zIndex: 300, width: 170, maxHeight: 230, overflowY: "auto", boxShadow: `0 4px 20px rgba(0,0,0,${dark?0.4:0.1})` }}>
                {LANGUAGES.map(l => <button key={l.code} onClick={() => { setLang(l.code); setShowLang(false); }} style={{ width: "100%", display: "flex", alignItems: "center", gap: 7, padding: "6px 8px", borderRadius: 5, background: lang===l.code?T.al:"transparent", border: "none", color: lang===l.code?T.ac:T.mi, cursor: "pointer", fontSize: 13, fontWeight: lang===l.code?600:400, textAlign: "left" }}>{l.flag} {l.code}</button>)}
              </div>}
            </div>
            <button onClick={() => setDark(d => !d)} style={{ padding: "5px 9px", borderRadius: 6, border: `1px solid ${T.br}`, background: T.cd, color: T.su, cursor: "pointer", fontSize: 12 }}>{dark?"Light":"Dark"}</button>
            {/* Profile Menu */}
            <div style={{ position: "relative" }}>
              <button onClick={() => { setShowMenu(v => !v); setShowLang(false); }} style={{ display: "flex", alignItems: "center", gap: 6, padding: "4px 10px 4px 4px", borderRadius: 20, border: `1px solid ${T.br}`, background: T.cd, cursor: "pointer" }}>
                <Avatar name={user.name} size={24} />
                <span style={{ fontSize: 13, fontWeight: 500, color: T.tx, maxWidth: 80, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{user.name.split(" ")[0]}</span>
              </button>
              {showMenu && <div style={{ position: "absolute", right: 0, top: "calc(100% + 6px)", background: T.cd, border: `1px solid ${T.br}`, borderRadius: 9, padding: 8, zIndex: 300, width: 200, boxShadow: `0 4px 20px rgba(0,0,0,${dark?0.4:0.1})` }}>
                <div style={{ padding: "8px 8px 12px", borderBottom: `1px solid ${T.br}`, marginBottom: 6 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 6 }}><Avatar name={user.name} size={34} /><div><div style={{ fontWeight: 600, fontSize: 13, color: T.tx }}>{user.name}</div><div style={{ fontSize: 11, color: T.su }}>{user.email}</div></div></div>
                  <Badge label={planLabel[user.plan||"free"]} color={planColor[user.plan||"free"]} />
                </div>
                {[{l:"Dashboard",t:"dashboard"},{l:"Profile",t:"profile"},{l:"Settings",t:"settings"},{l:"Upgrade",t:"upgrade"}].map(i => <button key={i.l} onClick={() => { setTool(i.t); setShowMenu(false); }} style={{ width: "100%", padding: "8px 9px", borderRadius: 6, border: "none", background: tool===i.t?T.al:"transparent", color: tool===i.t?T.ac:T.mi, cursor: "pointer", fontSize: 13, fontWeight: tool===i.t?600:400, textAlign: "left", display: "block" }}>{i.l}</button>)}
                <div style={{ borderTop: `1px solid ${T.br}`, marginTop: 6, paddingTop: 6 }}>
                  <button onClick={() => { setView("landing"); setShowMenu(false); }} style={{ width: "100%", padding: "8px 9px", borderRadius: 6, border: "none", background: "transparent", color: T.su, cursor: "pointer", fontSize: 13, textAlign: "left" }}>← Home</button>
                  <button onClick={logout} style={{ width: "100%", padding: "8px 9px", borderRadius: 6, border: "none", background: "transparent", color: T.rd, cursor: "pointer", fontSize: 13, fontWeight: 600, textAlign: "left" }}>Log Out</button>
                </div>
              </div>}
            </div>
          </div>
        </header>

        <div style={{ display: "flex", flex: 1, overflow: "hidden" }}>
          {/* SIDEBAR */}
          {sidebar && <aside style={{ width: 195, background: T.sb, borderRight: `1px solid ${T.br}`, padding: "12px 8px", overflowY: "auto", flexShrink: 0 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: T.su, letterSpacing: "0.8px", textTransform: "uppercase", padding: "4px 8px 8px" }}>Tools</div>
            {NAVTOOLS.map(t => <button key={t.id} onClick={() => setTool(t.id)} style={{ width: "100%", display: "flex", alignItems: "center", padding: "8px 10px", borderRadius: 6, border: "none", background: tool===t.id?T.al:"transparent", color: tool===t.id?T.ac:T.mi, cursor: "pointer", fontSize: 13, fontWeight: tool===t.id?600:400, marginBottom: 2, textAlign: "left" }}>{t.label}</button>)}
          </aside>}

          {/* MAIN CONTENT */}
          <main style={{ flex: 1, overflowY: "auto", padding: "28px 28px 80px" }}>
            <div style={{ maxWidth: 720 }}>

              {/* ─── DASHBOARD ─── */}
              {tool === "dashboard" && <div>
                <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 24, paddingBottom: 18, borderBottom: `1px solid ${T.br}` }}>
                  <Avatar name={user.name} size={52} />
                  <div>
                    <h1 style={{ fontSize: 20, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Good day, {user.name.split(" ")[0]}</h1>
                    <p style={{ fontSize: 13, color: T.su, margin: 0 }}>{user.businessName||"ClientAI"}{user.country ? ` · ${user.country}` : ""} · Member since {user.joined}</p>
                    <div style={{ marginTop: 6 }}><Badge label={planLabel[user.plan||"free"]} color={planColor[user.plan||"free"]} /></div>
                  </div>
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(140px,1fr))", gap: 12, marginBottom: 16 }}>
                  {[{label:"Strategies",val:history.length},{label:"Clients",val:clients.length},{label:"Follow-ups",val:fus.length},{label:"Plan",val:(user.plan||"free").toUpperCase()}].map(s => <Card key={s.label} extra={{ marginBottom: 0, padding: 16 }}><div style={{ fontSize: 11, color: T.su, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 6 }}>{s.label}</div><div style={{ fontSize: 26, fontWeight: 700, color: T.tx }}>{s.val}</div></Card>)}
                </div>
                <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>All Tools — Click to Open</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(210px,1fr))", gap: 14, marginBottom: 16 }}>
                  {[
                    { id:"generate", label:"Strategy Generator", desc:"Full client acquisition plan with outreach messages and weekly action plan.", color:"#7c3aed", grad:"135deg,#7c3aed,#a78bfa", features:["Outreach messages","Weekly action plan","WhatsApp & Email"], stickers:["⚡","✨","🎯"],
                      svg: <svg viewBox="0 0 80 80" width="80" height="80"><defs><radialGradient id="g1" cx="40%" cy="30%"><stop offset="0%" stopColor="#c4b5fd"/><stop offset="100%" stopColor="#7c3aed"/></radialGradient><filter id="s1"><feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#7c3aed" floodOpacity="0.5"/></filter></defs><ellipse cx="40" cy="68" rx="28" ry="5" fill="#7c3aed" opacity="0.2"/><path d="M20 50 L40 12 L60 50 Z" fill="url(#g1)" filter="url(#s1)" rx="4"/><polygon points="40,14 58,48 22,48" fill="url(#g1)"/><rect x="27" y="49" width="26" height="6" rx="3" fill="#a78bfa"/><circle cx="40" cy="30" r="6" fill="#fff" opacity="0.9"/><path d="M37 30 L39 32 L43 27" stroke="#7c3aed" strokeWidth="2" fill="none" strokeLinecap="round"/><circle cx="55" cy="20" r="4" fill="#c4b5fd" opacity="0.7"/><circle cx="25" cy="25" r="3" fill="#ddd6fe" opacity="0.5"/></svg> },

                    { id:"tracker", label:"Client Tracker", desc:"Track every lead from first contact to closed deal with pipeline management.", color:"#1d4ed8", grad:"135deg,#1d4ed8,#60a5fa", features:["Pipeline view","Status tracking","Deal stages"], stickers:["👥","📊","🏆"],
                      svg: <svg viewBox="0 0 80 80" width="80" height="80"><defs><radialGradient id="g2" cx="40%" cy="30%"><stop offset="0%" stopColor="#93c5fd"/><stop offset="100%" stopColor="#1d4ed8"/></radialGradient><filter id="s2"><feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#1d4ed8" floodOpacity="0.4"/></filter></defs><ellipse cx="40" cy="70" rx="26" ry="4" fill="#1d4ed8" opacity="0.2"/><rect x="14" y="18" width="52" height="44" rx="8" fill="url(#g2)" filter="url(#s2)"/><rect x="19" y="28" width="42" height="5" rx="2.5" fill="#fff" opacity="0.9"/><rect x="19" y="37" width="30" height="4" rx="2" fill="#fff" opacity="0.6"/><rect x="19" y="45" width="36" height="4" rx="2" fill="#fff" opacity="0.6"/><rect x="19" y="53" width="22" height="4" rx="2" fill="#fff" opacity="0.4"/><circle cx="59" cy="25" r="8" fill="#bfdbfe"/><path d="M56 25 L58 27 L63 22" stroke="#1d4ed8" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg> },

                    { id:"history", label:"Strategy History", desc:"All your strategies auto-saved. Review, copy, or download any past plan.", color:"#b45309", grad:"135deg,#b45309,#f59e0b", features:["Auto-save","Full view","Download"], stickers:["📂","⏰","💾"],
                      svg: <svg viewBox="0 0 80 80" width="80" height="80"><defs><radialGradient id="g3" cx="40%" cy="30%"><stop offset="0%" stopColor="#fcd34d"/><stop offset="100%" stopColor="#b45309"/></radialGradient><filter id="s3"><feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#b45309" floodOpacity="0.4"/></filter></defs><ellipse cx="40" cy="70" rx="26" ry="4" fill="#b45309" opacity="0.2"/><circle cx="40" cy="38" r="24" fill="url(#g3)" filter="url(#s3)"/><circle cx="40" cy="38" r="18" fill="#fef3c7" opacity="0.2"/><path d="M40 22 L40 38 L50 44" stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round"/><circle cx="40" cy="38" r="2.5" fill="#fff"/><circle cx="57" cy="21" r="5" fill="#fcd34d" opacity="0.8"/><circle cx="23" cy="21" r="3.5" fill="#fde68a" opacity="0.6"/></svg> },

                    { id:"social", label:"Social Media Posts", desc:"3 ready-to-publish posts with hashtags for any platform in any language.", color:"#0891b2", grad:"135deg,#0891b2,#22d3ee", features:["3 posts at once","Hashtags","All platforms"], stickers:["📱","🔥","💫"],
                      svg: <svg viewBox="0 0 80 80" width="80" height="80"><defs><radialGradient id="g4" cx="40%" cy="30%"><stop offset="0%" stopColor="#67e8f9"/><stop offset="100%" stopColor="#0891b2"/></radialGradient><filter id="s4"><feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#0891b2" floodOpacity="0.4"/></filter></defs><ellipse cx="40" cy="70" rx="26" ry="4" fill="#0891b2" opacity="0.2"/><rect x="16" y="14" width="28" height="34" rx="7" fill="url(#g4)" filter="url(#s4)"/><rect x="36" y="22" width="28" height="34" rx="7" fill="#0891b2" opacity="0.7"/><circle cx="30" cy="26" r="5" fill="#fff" opacity="0.9"/><rect x="20" y="34" width="20" height="3" rx="1.5" fill="#fff" opacity="0.7"/><rect x="20" y="40" width="14" height="3" rx="1.5" fill="#fff" opacity="0.5"/><circle cx="50" cy="34" r="5" fill="#cffafe" opacity="0.8"/><rect x="40" y="42" width="20" height="3" rx="1.5" fill="#fff" opacity="0.7"/><rect x="40" y="48" width="14" height="3" rx="1.5" fill="#fff" opacity="0.5"/></svg> },

                    { id:"pricing", label:"Pricing Calculator", desc:"Know exactly what to charge based on your market, experience and project.", color:"#15803d", grad:"135deg,#15803d,#4ade80", features:["Low/Mid/High","Market rates","Premium tips"], stickers:["💰","📈","💎"],
                      svg: <svg viewBox="0 0 80 80" width="80" height="80"><defs><radialGradient id="g5" cx="40%" cy="30%"><stop offset="0%" stopColor="#86efac"/><stop offset="100%" stopColor="#15803d"/></radialGradient><filter id="s5"><feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#15803d" floodOpacity="0.4"/></filter></defs><ellipse cx="40" cy="70" rx="26" ry="4" fill="#15803d" opacity="0.2"/><circle cx="40" cy="38" r="24" fill="url(#g5)" filter="url(#s5)"/><text x="40" y="46" textAnchor="middle" fontSize="24" fontWeight="900" fill="#fff" fontFamily="Georgia,serif">$</text><circle cx="57" cy="22" r="6" fill="#bbf7d0" opacity="0.9"/><circle cx="23" cy="54" r="4" fill="#dcfce7" opacity="0.6"/><path d="M28 38 L34 32 L40 36 L48 28 L54 32" stroke="#fff" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" opacity="0.8"/></svg> },

                    { id:"invoice", label:"Invoice Generator", desc:"Professional invoices in seconds. 10 currencies, copy or download instantly.", color:"#6d28d9", grad:"135deg,#6d28d9,#a78bfa", features:["10 currencies","Professional","Copy & Download"], stickers:["🧾","✅","💳"],
                      svg: <svg viewBox="0 0 80 80" width="80" height="80"><defs><radialGradient id="g6" cx="40%" cy="30%"><stop offset="0%" stopColor="#c4b5fd"/><stop offset="100%" stopColor="#6d28d9"/></radialGradient><filter id="s6"><feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#6d28d9" floodOpacity="0.4"/></filter></defs><ellipse cx="40" cy="70" rx="26" ry="4" fill="#6d28d9" opacity="0.2"/><rect x="16" y="12" width="48" height="56" rx="8" fill="url(#g6)" filter="url(#s6)"/><rect x="22" y="20" width="36" height="4" rx="2" fill="#fff" opacity="0.9"/><rect x="22" y="28" width="24" height="3" rx="1.5" fill="#fff" opacity="0.6"/><rect x="22" y="34" width="20" height="3" rx="1.5" fill="#fff" opacity="0.5"/><rect x="22" y="40" width="28" height="3" rx="1.5" fill="#fff" opacity="0.5"/><rect x="22" y="50" width="36" height="8" rx="4" fill="#fff" opacity="0.2"/><rect x="24" y="53" width="20" height="2.5" rx="1.2" fill="#fff" opacity="0.8"/><circle cx="57" cy="52" r="7" fill="#ddd6fe" opacity="0.9"/><path d="M54.5 52 L56.5 54 L60 49.5" stroke="#6d28d9" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg> },

                    { id:"proposal", label:"Proposal Builder", desc:"Win more clients with persuasive AI proposals tailored to each client.", color:"#1e40af", grad:"135deg,#1e40af,#3b82f6", features:["Full proposal","Client-specific","Next steps"], stickers:["📄","🏅","🤝"],
                      svg: <svg viewBox="0 0 80 80" width="80" height="80"><defs><radialGradient id="g7" cx="40%" cy="30%"><stop offset="0%" stopColor="#93c5fd"/><stop offset="100%" stopColor="#1e40af"/></radialGradient><filter id="s7"><feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#1e40af" floodOpacity="0.4"/></filter></defs><ellipse cx="40" cy="70" rx="26" ry="4" fill="#1e40af" opacity="0.2"/><rect x="18" y="10" width="44" height="56" rx="8" fill="url(#g7)" filter="url(#s7)"/><rect x="24" y="18" width="32" height="5" rx="2.5" fill="#fff" opacity="0.95"/><rect x="24" y="27" width="28" height="3" rx="1.5" fill="#fff" opacity="0.6"/><rect x="24" y="33" width="32" height="3" rx="1.5" fill="#fff" opacity="0.5"/><rect x="24" y="39" width="24" height="3" rx="1.5" fill="#fff" opacity="0.5"/><rect x="24" y="45" width="32" height="3" rx="1.5" fill="#fff" opacity="0.4"/><path d="M24 54 L44 54" stroke="#fff" strokeWidth="2" strokeDasharray="3,2" opacity="0.5"/><circle cx="56" cy="57" r="7" fill="#bfdbfe" opacity="0.9"/><path d="M53 57 L55.5 59.5 L59.5 54.5" stroke="#1e40af" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg> },

                    { id:"followup", label:"Follow-up Manager", desc:"Schedule reminders and let AI write perfect follow-up messages for each lead.", color:"#b45309", grad:"135deg,#b45309,#fbbf24", features:["Reminders","AI messages","WhatsApp send"], stickers:["🔔","⏰","💬"],
                      svg: <svg viewBox="0 0 80 80" width="80" height="80"><defs><radialGradient id="g8" cx="40%" cy="30%"><stop offset="0%" stopColor="#fcd34d"/><stop offset="100%" stopColor="#b45309"/></radialGradient><filter id="s8"><feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#b45309" floodOpacity="0.4"/></filter></defs><ellipse cx="40" cy="70" rx="26" ry="4" fill="#b45309" opacity="0.2"/><path d="M18 52 Q18 20 40 16 Q62 20 62 52 L58 56 L40 60 L22 56 Z" fill="url(#g8)" filter="url(#s8)"/><rect x="34" y="58" width="12" height="7" rx="3.5" fill="#fcd34d"/><rect x="16" y="52" width="48" height="6" rx="3" fill="#fde68a" opacity="0.6"/><circle cx="40" cy="36" r="7" fill="#fff" opacity="0.85"/><path d="M37 36 L39.5 38.5 L44 33" stroke="#b45309" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round"/><circle cx="59" cy="22" r="5" fill="#fef3c7" opacity="0.9"/><path d="M57 22 L59 24 L62 20" stroke="#b45309" strokeWidth="1.5" fill="none" strokeLinecap="round"/></svg> },

                    { id:"naming", label:"Business Name AI", desc:"Generate 10 unique business names with meanings, domain tips and taglines.", color:"#0e7490", grad:"135deg,#0e7490,#06b6d4", features:["10 names","Domain tips","Taglines"], stickers:["✨","🌟","💡"],
                      svg: <svg viewBox="0 0 80 80" width="80" height="80"><defs><radialGradient id="g9" cx="40%" cy="30%"><stop offset="0%" stopColor="#67e8f9"/><stop offset="100%" stopColor="#0e7490"/></radialGradient><filter id="s9"><feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#0e7490" floodOpacity="0.4"/></filter></defs><ellipse cx="40" cy="70" rx="26" ry="4" fill="#0e7490" opacity="0.2"/><polygon points="40,10 52,34 78,34 57,50 65,74 40,58 15,74 23,50 2,34 28,34" fill="url(#g9)" filter="url(#s9)"/><polygon points="40,18 49,36 68,36 53,47 59,65 40,54 21,65 27,47 12,36 31,36" fill="#cffafe" opacity="0.25"/><text x="40" y="45" textAnchor="middle" fontSize="14" fontWeight="900" fill="#fff" fontFamily="Arial,sans-serif">✦</text></svg> },

                    { id:"competitor", label:"Competitor Analysis", desc:"Identify market gaps, differentiate your offer, and win clients from competitors.", color:"#065f46", grad:"135deg,#065f46,#10b981", features:["Market gaps","Positioning","Win tactics"], stickers:["🔍","🎯","🏆"],
                      svg: <svg viewBox="0 0 80 80" width="80" height="80"><defs><radialGradient id="g10" cx="40%" cy="30%"><stop offset="0%" stopColor="#6ee7b7"/><stop offset="100%" stopColor="#065f46"/></radialGradient><filter id="s10"><feDropShadow dx="0" dy="4" stdDeviation="4" floodColor="#065f46" floodOpacity="0.4"/></filter></defs><ellipse cx="40" cy="70" rx="26" ry="4" fill="#065f46" opacity="0.2"/><circle cx="36" cy="36" r="20" fill="url(#g10)" filter="url(#s10)"/><circle cx="36" cy="36" r="14" fill="#d1fae5" opacity="0.2"/><circle cx="36" cy="36" r="7" fill="#fff" opacity="0.3"/><circle cx="36" cy="36" r="2.5" fill="#fff" opacity="0.9"/><line x1="36" y1="16" x2="36" y2="20" stroke="#fff" strokeWidth="2" strokeLinecap="round"/><line x1="36" y1="52" x2="36" y2="56" stroke="#fff" strokeWidth="2" strokeLinecap="round"/><line x1="16" y1="36" x2="20" y2="36" stroke="#fff" strokeWidth="2" strokeLinecap="round"/><line x1="52" y1="36" x2="56" y2="36" stroke="#fff" strokeWidth="2" strokeLinecap="round"/><path d="M50 50 L62 62" stroke="#6ee7b7" strokeWidth="3" strokeLinecap="round"/><circle cx="63" cy="63" r="5" fill="#a7f3d0" opacity="0.8"/></svg> },
                  ].map(tool2 => (
                    <div key={tool2.id} onClick={() => setTool(tool2.id)}
                      style={{ background: T.cd, border: `1px solid ${T.br}`, borderRadius: 14, padding: "0 0 16px", cursor: "pointer", display: "flex", flexDirection: "column", overflow: "hidden", boxShadow: dark ? "0 2px 12px rgba(0,0,0,0.3)" : "0 2px 12px rgba(0,0,0,0.06)", transition: "transform 0.15s, box-shadow 0.15s" }}
                      onMouseEnter={e => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = dark ? `0 12px 32px rgba(0,0,0,0.45)` : `0 12px 28px rgba(0,0,0,0.13)`; }}
                      onMouseLeave={e => { e.currentTarget.style.transform = "translateY(0)"; e.currentTarget.style.boxShadow = dark ? "0 2px 12px rgba(0,0,0,0.3)" : "0 2px 12px rgba(0,0,0,0.06)"; }}>
                      {/* Card header with gradient + 3D + stickers */}
                      <div style={{ background: `linear-gradient(${tool2.grad})`, borderRadius: "14px 14px 0 0", padding: "18px 0 10px", display: "flex", alignItems: "center", justifyContent: "center", position: "relative", minHeight: 120, overflow: "hidden" }}>
                        {/* Background decoration circles */}
                        <div style={{ position: "absolute", top: -14, right: -14, width: 70, height: 70, borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
                        <div style={{ position: "absolute", bottom: -10, left: -10, width: 50, height: 50, borderRadius: "50%", background: "rgba(255,255,255,0.05)" }} />
                        <div style={{ position: "absolute", top: 6, left: 10, width: 30, height: 30, borderRadius: "50%", background: "rgba(255,255,255,0.06)" }} />
                        {/* Floating sticker top-left */}
                        <div style={{ position: "absolute", top: 8, left: 10, fontSize: 16, filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.3))", userSelect: "none" }}>{tool2.stickers[0]}</div>
                        {/* Floating sticker top-right */}
                        <div style={{ position: "absolute", top: 10, right: 12, fontSize: 13, filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.25))", userSelect: "none" }}>{tool2.stickers[1]}</div>
                        {/* Floating sticker bottom-right */}
                        <div style={{ position: "absolute", bottom: 8, right: 10, fontSize: 15, filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.25))", userSelect: "none" }}>{tool2.stickers[2]}</div>
                        {/* 3D SVG illustration */}
                        <div style={{ filter: "drop-shadow(0 8px 16px rgba(0,0,0,0.4))", transform: "scale(1.08)", zIndex: 1 }}>
                          {tool2.svg}
                        </div>
                      </div>
                      {/* Card body */}
                      <div style={{ padding: "14px 16px 0" }}>
                        <div style={{ fontWeight: 700, fontSize: 13, color: T.tx, marginBottom: 5, lineHeight: 1.3 }}>{tool2.label}</div>
                        <p style={{ fontSize: 11.5, color: T.su, lineHeight: 1.6, margin: "0 0 10px" }}>{tool2.desc}</p>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 4, marginBottom: 10 }}>
                          {tool2.features.map(f => <span key={f} style={{ fontSize: 10, color: tool2.color, background: `${tool2.color}12`, border: `1px solid ${tool2.color}25`, borderRadius: 4, padding: "2px 6px", fontWeight: 600 }}>{f}</span>)}
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12, fontWeight: 600, color: tool2.color }}>Open <span style={{ fontSize: 14 }}>→</span></div>
                      </div>
                    </div>
                  ))}
                </div>
                {user.plan === "free" && <Card extra={{ borderColor: T.ab, background: T.al }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div><div style={{ fontWeight: 600, fontSize: 14, color: T.tx, marginBottom: 3 }}>Upgrade to Pro</div><div style={{ fontSize: 13, color: T.mi }}>Unlock all 10 tools, 24 languages, unlimited strategies</div></div>
                    <Btn label="Upgrade" onClick={() => setTool("upgrade")} variant="primary" size="sm" />
                  </div>
                </Card>}
                {history.length > 0 && <Card>
                  <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 12 }}>Recent Strategies</div>
                  {history.slice(0, 3).map(h => <div key={h.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderBottom: `1px solid ${T.br}` }}><div><div style={{ fontSize: 13, fontWeight: 600, color: T.tx }}>{h.company}</div><div style={{ fontSize: 11, color: T.su }}>{h.date} · {h.lang}</div></div><Btn label="View" onClick={() => { setViewHist(h); setTool("history"); }} variant="secondary" size="sm" /></div>)}
                </Card>}
              </div>}

              {/* ─── STRATEGY GENERATOR ─── */}
              {tool === "generate" && <div>
                <div style={{ marginBottom: 20 }}>
                  <h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Strategy Generator</h2>
                  <p style={{ fontSize: 13, color: T.su, margin: 0 }}>Generate a complete, personalised client acquisition plan powered by AI · {LANGUAGES.find(l=>l.code===lang)?.flag} {lang}</p>
                </div>

                {/* Step 0: Business Info */}
                {gs === 0 && <div>
                  <Card>
                    <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 16 }}>Your Business</div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                      <F label="Full Name"><I value={gf.name} onChange={e => setGf(f => ({...f,name:e.target.value}))} placeholder="Your name" /></F>
                      <F label="Company Name"><I value={gf.company} onChange={e => setGf(f => ({...f,company:e.target.value}))} placeholder="Your company" /></F>
                      <F label="Phone / WhatsApp"><I value={gf.phone} onChange={e => setGf(f => ({...f,phone:e.target.value}))} placeholder="+66 89 000 0000" /></F>
                      <F label="Email"><I value={gf.email} onChange={e => setGf(f => ({...f,email:e.target.value}))} placeholder="you@email.com" /></F>
                      <F label="Monthly Budget (optional)"><I value={gf.budget} onChange={e => setGf(f => ({...f,budget:e.target.value}))} placeholder="e.g. $500" /></F>
                    </div>
                    <F label="Your Industry"><PillSel options={industries} value={gf.industry} onChange={v => setGf(f => ({...f,industry:v}))} /></F>
                    <F label="Services You Offer"><MultiPill options={services} value={gf.offering} onChange={v => toggleOffer("offering",v)} color="#15803d" /></F>
                    <F label="Services You Don't Offer" mb={0}><MultiPill options={services} value={gf.notWanting} onChange={v => toggleOffer("notWanting",v)} color="#b91c1c" /></F>
                  </Card>
                  <Btn label="Next: Define Target Client →" onClick={() => setGs(1)} disabled={!gf.name || !gf.company || !gf.industry} variant="primary" full />
                </div>}

                {/* Step 1: Target */}
                {gs === 1 && <div>
                  <Card>
                    <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 16 }}>Target Client</div>
                    <F label="Target Location"><I value={gf.targetLocation} onChange={e => setGf(f => ({...f,targetLocation:e.target.value}))} placeholder="e.g. Bangkok, Thailand" /></F>
                    <F label="Target Industry"><PillSel options={industries} value={gf.targetIndustry} onChange={v => setGf(f => ({...f,targetIndustry:v}))} color="#1d4ed8" /></F>
                    <F label="Your Goal" mb={0}><TA value={gf.goal} onChange={e => setGf(f => ({...f,goal:e.target.value}))} placeholder="e.g. Sign 5 restaurant clients in Bangkok within 30 days" rows={3} /></F>
                  </Card>
                  <div style={{ display: "flex", gap: 10 }}>
                    <Btn label="← Back" onClick={() => setGs(0)} variant="secondary" />
                    <div style={{ flex: 1 }}><Btn label={`Generate Strategy in ${lang}`} onClick={generateStrategy} disabled={!gf.targetLocation || !gf.targetIndustry} variant="primary" full /></div>
                  </div>
                </div>}

                {/* Step 2: Result */}
                {gs === 2 && <div>
                  {gLoading && <Card>
                    <div style={{ padding: "32px 20px", textAlign: "center" }}>
                      <div style={{ fontSize: 14, fontWeight: 600, color: T.tx, marginBottom: 8 }}>Generating your strategy in {lang}...</div>
                      <p style={{ fontSize: 13, color: T.su, marginBottom: 20 }}>AI is analysing your profile and building a personalised plan</p>
                      <div style={{ height: 3, background: T.br, borderRadius: 3, overflow: "hidden", maxWidth: 320, margin: "0 auto" }}>
                        <div style={{ height: "100%", width: "65%", background: "#7c3aed", borderRadius: 3 }} />
                      </div>
                    </div>
                  </Card>}

                  {gErr && <Card extra={{ borderColor: `${T.rd}40`, background: T.rdb }}>
                    <p style={{ color: T.rd, fontSize: 13, margin: 0 }}>{gErr}</p>
                    <div style={{ marginTop: 10 }}><Btn label="Try Again" onClick={() => { setGs(1); setGErr(""); }} variant="secondary" size="sm" /></div>
                  </Card>}

                  {gResult && !gLoading && <div>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                      <div>
                        <h3 style={{ fontSize: 15, fontWeight: 700, margin: "0 0 2px", color: T.tx }}>Strategy for {gf.company}</h3>
                        <p style={{ fontSize: 12, color: T.su, margin: 0 }}>{LANGUAGES.find(l=>l.code===lang)?.flag} {lang} · {gf.targetIndustry} in {gf.targetLocation}</p>
                      </div>
                      <Btn label="New Strategy" onClick={() => { setGs(0); setGResult(null); setGErr(""); setGParsed({whatsapp:[],emails:[]}); }} variant="secondary" size="sm" />
                    </div>

                    {/* Tabs */}
                    <div style={{ display: "flex", gap: 0, borderBottom: `1px solid ${T.br}`, marginBottom: 16 }}>
                      {[{id:"strategy",l:"Full Strategy"},{id:"whatsapp",l:"WhatsApp Messages"},{id:"email",l:"Email Templates"}].map(t => <button key={t.id} onClick={() => setGTab(t.id)} style={{ padding: "9px 18px", background: "transparent", border: "none", borderBottom: `2px solid ${gTab===t.id?"#7c3aed":"transparent"}`, color: gTab===t.id?T.ac:T.su, cursor: "pointer", fontSize: 13, fontWeight: gTab===t.id?600:400 }}>{t.l}</button>)}
                    </div>

                    {gTab === "strategy" && <ResultBox text={gResult} id="gen" filename={`${gf.company}_strategy.txt`} />}

                    {gTab === "whatsapp" && (gParsed.whatsapp.length > 0 ? gParsed.whatsapp.map((msg, i) => <Card key={i}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 8 }}>{msg.label}</div>
                      <p style={{ fontSize: 14, color: T.mi, lineHeight: 1.75, margin: "0 0 14px", fontFamily: "'Georgia',serif" }}>{msg.body.join(" ")}</p>
                      <div style={{ display: "flex", gap: 8 }}>
                        <Btn label={copied===`wa${i}`?"Copied!":"Copy"} onClick={() => copy(msg.body.join(" "), `wa${i}`)} variant="secondary" size="sm" />
                        <Btn label="Open in WhatsApp" onClick={() => openWA(msg.body.join(" "))} variant="primary" size="sm" />
                      </div>
                    </Card>) : <Card><p style={{ color: T.su, fontSize: 13, margin: 0 }}>See Full Strategy tab — outreach messages are included there.</p></Card>)}

                    {gTab === "email" && (gParsed.emails.length > 0 ? gParsed.emails.map((em, i) => <Card key={i}>
                      <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 8 }}>Email Template {i+1}</div>
                      <div style={{ background: T.in, border: `1px solid ${T.br}`, borderRadius: 6, padding: "7px 11px", marginBottom: 10 }}>
                        <span style={{ fontSize: 11, color: T.su }}>Subject: </span><span style={{ fontSize: 13, color: T.tx, fontWeight: 600 }}>{em.subject}</span>
                      </div>
                      <p style={{ fontSize: 14, color: T.mi, lineHeight: 1.75, margin: "0 0 14px", fontFamily: "'Georgia',serif" }}>{em.body.join(" ")}</p>
                      <div style={{ display: "flex", gap: 8 }}>
                        <Btn label={copied===`em${i}`?"Copied!":"Copy"} onClick={() => copy(`Subject: ${em.subject}\n\n${em.body.join("\n")}`, `em${i}`)} variant="secondary" size="sm" />
                        <Btn label="Open in Email" onClick={() => openMail(em.subject, em.body.join("\n"))} variant="primary" size="sm" />
                      </div>
                    </Card>) : <Card><p style={{ color: T.su, fontSize: 13, margin: 0 }}>See Full Strategy tab — email templates are included there.</p></Card>)}
                  </div>}
                </div>}
              </div>}

              {/* ─── HISTORY ─── */}
              {tool === "history" && <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                  <div><h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Strategy History</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>{history.length} strategies saved</p></div>
                </div>
                {viewHist ? <div>
                  <div style={{ marginBottom: 14, display: "flex", gap: 10, alignItems: "center" }}>
                    <Btn label="← All Strategies" onClick={() => setViewHist(null)} variant="secondary" size="sm" />
                    <span style={{ fontSize: 14, fontWeight: 600, color: T.tx }}>{viewHist.company}</span>
                    <span style={{ fontSize: 12, color: T.su }}>{viewHist.date} · {viewHist.lang}</span>
                  </div>
                  <ResultBox text={viewHist.text} id="hist" filename={`${viewHist.company}_strategy.txt`} />
                </div> : history.length === 0 ? <Card><div style={{ textAlign: "center", padding: "32px 0" }}><p style={{ color: T.su, fontSize: 14, margin: "0 0 14px" }}>No strategies yet.</p><Btn label="Generate Your First Strategy" onClick={() => setTool("generate")} variant="primary" /></div></Card>
                : history.map(h => <Card key={h.id} extra={{ padding: "14px 16px" }}><div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}><div><div style={{ fontSize: 14, fontWeight: 600, color: T.tx }}>{h.company}</div><div style={{ fontSize: 12, color: T.su }}>{h.date} · {h.lang} · {h.targetIndustry} in {h.targetLocation}</div></div><Btn label="View" onClick={() => setViewHist(h)} variant="secondary" size="sm" /></div></Card>)}
              </div>}

              {/* ─── CLIENT TRACKER ─── */}
              {tool === "tracker" && <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                  <div><h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Client Tracker</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>{clients.length} clients tracked</p></div>
                  <Btn label={showAddCl?"Cancel":"+ Add Client"} onClick={() => setShowAddCl(v => !v)} variant={showAddCl?"secondary":"primary"} size="sm" />
                </div>
                {showAddCl && <Card>
                  <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>New Client</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <F label="Client Name"><I value={newCl.name} onChange={e => setNewCl(f => ({...f,name:e.target.value}))} placeholder="Full name" /></F>
                    <F label="Company"><I value={newCl.company} onChange={e => setNewCl(f => ({...f,company:e.target.value}))} placeholder="Company name" /></F>
                    <F label="Contact"><I value={newCl.contact} onChange={e => setNewCl(f => ({...f,contact:e.target.value}))} placeholder="Phone or email" /></F>
                    <F label="Status"><Sel value={newCl.status} onChange={e => setNewCl(f => ({...f,status:e.target.value}))} options={Object.keys(statusColors)} /></F>
                  </div>
                  <F label="Notes" mb={12}><TA value={newCl.notes} onChange={e => setNewCl(f => ({...f,notes:e.target.value}))} placeholder="Notes about this client..." rows={2} /></F>
                  <Btn label="Save Client" onClick={() => { if (newCl.name) { setClients(c => [{ ...newCl, id: Date.now(), date: new Date().toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"}) }, ...c]); setNewCl({name:"",company:"",contact:"",status:"Not Contacted",notes:""}); setShowAddCl(false); } }} variant="primary" size="sm" />
                </Card>}
                {clients.length > 0 && <Card extra={{ padding: "12px 16px", marginBottom: 14 }}>
                  <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
                    {Object.entries(statusColors).map(([s,c]) => { const count = clients.filter(x => x.status === s).length; return count > 0 && <div key={s} style={{ textAlign: "center" }}><div style={{ fontSize: 20, fontWeight: 700, color: c }}>{count}</div><div style={{ fontSize: 10, color: T.su, marginTop: 1 }}>{s.replace(" ✅","").replace(" ❌","")}</div></div>; }).filter(Boolean)}
                  </div>
                </Card>}
                {clients.length === 0 && !showAddCl && <Card><div style={{ textAlign: "center", padding: "32px 0" }}><p style={{ color: T.su, fontSize: 14, margin: 0 }}>No clients yet.</p></div></Card>}
                {clients.map(c => <Card key={c.id} extra={{ padding: "14px 16px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 3 }}>
                        <span style={{ fontSize: 14, fontWeight: 600, color: T.tx }}>{c.name}</span>
                        <Badge label={c.status} color={statusColors[c.status]} />
                      </div>
                      {c.company && <div style={{ fontSize: 12, color: T.su }}>{c.company}{c.contact ? ` · ${c.contact}` : ""}</div>}
                      {c.notes && <div style={{ fontSize: 12, color: T.su, marginTop: 4, fontStyle: "italic" }}>{c.notes}</div>}
                    </div>
                    <Btn label="Remove" onClick={() => setClients(cl => cl.filter(x => x.id !== c.id))} variant="danger" size="sm" />
                  </div>
                  <Hr />
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    <span style={{ fontSize: 11, color: T.su, fontWeight: 500, marginRight: 4, alignSelf: "center" }}>Move to:</span>
                    {Object.keys(statusColors).filter(s => s !== c.status).map(s => <button key={s} onClick={() => setClients(cl => cl.map(x => x.id===c.id ? {...x,status:s} : x))} style={{ padding: "3px 9px", borderRadius: 4, border: `1px solid ${statusColors[s]}40`, background: `${statusColors[s]}10`, color: statusColors[s], fontSize: 11, fontWeight: 600, cursor: "pointer" }}>{s}</button>)}
                  </div>
                </Card>)}
              </div>}

              {/* ─── SOCIAL ─── */}
              {tool === "social" && <div>
                <div style={{ marginBottom: 20 }}><h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Social Media Posts</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>Ready-to-publish content in {lang}</p></div>
                <Card>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <F label="Business Name"><I value={sf2.business} onChange={e => setSf2(f => ({...f,business:e.target.value}))} placeholder="Your business" /></F>
                    <F label="Niche / Specialty"><I value={sf2.niche} onChange={e => setSf2(f => ({...f,niche:e.target.value}))} placeholder="e.g. Web design for restaurants" /></F>
                    <F label="Platform"><Sel value={sf2.platform} onChange={e => setSf2(f => ({...f,platform:e.target.value}))} options={["Instagram","Facebook","LinkedIn","TikTok","Twitter / X"]} /></F>
                    <F label="Goal"><Sel value={sf2.goal} onChange={e => setSf2(f => ({...f,goal:e.target.value}))} options={["Get more clients","Promote a service","Share expertise","Build credibility","Product launch"]} /></F>
                    <F label="Tone"><Sel value={sf2.tone} onChange={e => setSf2(f => ({...f,tone:e.target.value}))} options={["Professional","Friendly","Educational","Inspiring","Direct"]} /></F>
                  </div>
                  <Btn label={sl ? "Generating..." : `Generate 3 Posts in ${lang}`} onClick={() => runAI(`Professional social media copywriter. Create 3 ready-to-publish ${sf2.platform} posts for: Business: ${sf2.business}, Niche: ${sf2.niche}, Goal: ${sf2.goal}, Tone: ${sf2.tone}. Respond entirely in ${lang}. Label: Post 1: / Post 2: / Post 3:. Each: compelling caption + 5 hashtags. Write professionally. Plain text only.`, setSr, setSl)} disabled={!sf2.business || sl} variant="primary" full />
                </Card>
                <ResultBox text={sr} id="social" filename="social_posts.txt" />
              </div>}

              {/* ─── PRICING ─── */}
              {tool === "pricing" && <div>
                <div style={{ marginBottom: 20 }}><h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Pricing Calculator</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>Find the right price for your services</p></div>
                <Card>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <F label="Service"><Sel value={pf2.service} onChange={e => setPf2(f => ({...f,service:e.target.value}))} options={services} /></F>
                    <F label="Estimated Hours"><I value={pf2.hours} onChange={e => setPf2(f => ({...f,hours:e.target.value}))} placeholder="e.g. 20" /></F>
                    <F label="Experience Level"><Sel value={pf2.experience} onChange={e => setPf2(f => ({...f,experience:e.target.value}))} options={["Entry Level (0–1 yr)","Intermediate (1–3 yrs)","Experienced (3–5 yrs)","Senior (5–10 yrs)","Expert (10+ yrs)"]} /></F>
                    <F label="Your Market / Location"><I value={pf2.location} onChange={e => setPf2(f => ({...f,location:e.target.value}))} placeholder="e.g. Bangkok, Thailand" /></F>
                    <F label="Project Type"><Sel value={pf2.type} onChange={e => setPf2(f => ({...f,type:e.target.value}))} options={["One-time Project","Monthly Retainer","Hourly Rate","Package / Bundle"]} /></F>
                  </div>
                  <Btn label={pl ? "Calculating..." : `Calculate Pricing in ${lang}`} onClick={() => runAI(`Freelance pricing consultant. Provide detailed pricing in ${lang} for: Service: ${pf2.service}, Hours: ${pf2.hours}, Experience: ${pf2.experience}, Market: ${pf2.location}, Type: ${pf2.type}. Give: 1) Low/Mid/High price range with justification. 2) How to present price confidently. 3) What to include in the package. 4) One strategy to command premium pricing. Write professionally in ${lang}. Plain text only.`, setPr, setPl)} disabled={!pf2.location || pl} variant="primary" full />
                </Card>
                <ResultBox text={pr} id="pricing" filename="pricing_advice.txt" />
              </div>}

              {/* ─── INVOICE ─── */}
              {tool === "invoice" && <div>
                <div style={{ marginBottom: 20 }}><h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Invoice Generator</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>Create professional invoices instantly</p></div>
                <Card>
                  <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>From (Your Details)</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <F label="Your Name / Company"><I value={inf.yourName} onChange={e => setInf(f => ({...f,yourName:e.target.value}))} placeholder="Your name or company" /></F>
                    <F label="Your Email"><I value={inf.yourEmail} onChange={e => setInf(f => ({...f,yourEmail:e.target.value}))} placeholder="you@email.com" /></F>
                  </div>
                  <Hr />
                  <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>To (Client Details)</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <F label="Client Name"><I value={inf.clientName} onChange={e => setInf(f => ({...f,clientName:e.target.value}))} placeholder="Client name" /></F>
                    <F label="Client Email"><I value={inf.clientEmail} onChange={e => setInf(f => ({...f,clientEmail:e.target.value}))} placeholder="client@email.com" /></F>
                  </div>
                  <Hr />
                  <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>Invoice Details</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
                    <F label="Currency"><Sel value={inf.currency} onChange={e => setInf(f => ({...f,currency:e.target.value}))} options={["USD","THB","EUR","GBP","INR","BDT","SGD","MYR","JPY","AUD"]} /></F>
                    <F label="Amount"><I value={inf.amount} onChange={e => setInf(f => ({...f,amount:e.target.value}))} placeholder="e.g. 1500" /></F>
                    <F label="Due Date"><I value={inf.dueDate} onChange={e => setInf(f => ({...f,dueDate:e.target.value}))} placeholder="e.g. 15 July 2026" /></F>
                  </div>
                  <F label="Service Description"><I value={inf.service} onChange={e => setInf(f => ({...f,service:e.target.value}))} placeholder="e.g. Website Design and Development — June 2026" /></F>
                  <F label="Payment Notes" mb={12}><I value={inf.notes} onChange={e => setInf(f => ({...f,notes:e.target.value}))} placeholder="e.g. Bank transfer to account 123-456-789" /></F>
                  <Btn label={il ? "Generating..." : `Generate Invoice in ${lang}`} onClick={() => runAI(`Professional invoice writer. Create a formal invoice in ${lang}: FROM: ${inf.yourName} (${inf.yourEmail}), TO: ${inf.clientName} (${inf.clientEmail}), SERVICE: ${inf.service}, AMOUNT: ${inf.currency} ${inf.amount}, DUE DATE: ${inf.dueDate}, PAYMENT NOTES: ${inf.notes||"N/A"}. Format as a clean professional invoice with invoice number, date, itemized breakdown, total, payment instructions, and polite closing. Plain text only. Write in ${lang}.`, setIr, setIl, 900)} disabled={!inf.yourName || !inf.clientName || !inf.amount || il} variant="primary" full />
                </Card>
                <ResultBox text={ir} id="invoice" filename="invoice.txt" />
              </div>}

              {/* ─── PROPOSAL ─── */}
              {tool === "proposal" && <div>
                <div style={{ marginBottom: 20 }}><h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Proposal Builder</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>Write winning client proposals with AI</p></div>
                <Card>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <F label="Your Name"><I value={prpf.yourName} onChange={e => setPrpf(f => ({...f,yourName:e.target.value}))} placeholder="Your full name" /></F>
                    <F label="Your Company"><I value={prpf.company} onChange={e => setPrpf(f => ({...f,company:e.target.value}))} placeholder="Your company" /></F>
                    <F label="Client Name"><I value={prpf.clientName} onChange={e => setPrpf(f => ({...f,clientName:e.target.value}))} placeholder="Client name" /></F>
                    <F label="Client's Business"><I value={prpf.clientBiz} onChange={e => setPrpf(f => ({...f,clientBiz:e.target.value}))} placeholder="e.g. Thai Bistro Restaurant" /></F>
                    <F label="Service Offering"><I value={prpf.service} onChange={e => setPrpf(f => ({...f,service:e.target.value}))} placeholder="e.g. Website Design + SEO" /></F>
                    <F label="Budget / Price"><I value={prpf.budget} onChange={e => setPrpf(f => ({...f,budget:e.target.value}))} placeholder="e.g. $1,200" /></F>
                    <F label="Timeline"><I value={prpf.timeline} onChange={e => setPrpf(f => ({...f,timeline:e.target.value}))} placeholder="e.g. 3 weeks" /></F>
                  </div>
                  <F label="Client's Problem / Current Situation" mb={12}><TA value={prpf.problem} onChange={e => setPrpf(f => ({...f,problem:e.target.value}))} placeholder="e.g. They have no website and are losing customers to competitors" rows={3} /></F>
                  <Btn label={prpl ? "Generating..." : `Generate Proposal in ${lang}`} onClick={() => runAI(`Expert proposal writer. Write a compelling professional proposal in ${lang}: YOUR NAME: ${prpf.yourName}, YOUR COMPANY: ${prpf.company}, CLIENT: ${prpf.clientName}, CLIENT BUSINESS: ${prpf.clientBiz}, SERVICE: ${prpf.service}, BUDGET: ${prpf.budget}, TIMELINE: ${prpf.timeline}, CLIENT PROBLEM: ${prpf.problem}. Include: Executive Summary, Problem Statement, Proposed Solution & Deliverables, Timeline, Investment Summary, Why Choose Us, Next Steps. Confident consultative tone. Plain text only. Write in ${lang}.`, setPrpr, setPrpl, 1200)} disabled={!prpf.yourName || !prpf.clientName || !prpf.service || prpl} variant="primary" full />
                </Card>
                <ResultBox text={prpr} id="proposal" filename="proposal.txt" />
              </div>}

              {/* ─── FOLLOW-UP ─── */}
              {tool === "followup" && <div>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                  <div><h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Follow-up Manager</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>{fus.length} follow-ups scheduled</p></div>
                  <Btn label={showFu?"Cancel":"+ Schedule Follow-up"} onClick={() => setShowFu(v => !v)} variant={showFu?"secondary":"primary"} size="sm" />
                </div>
                {showFu && <Card>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <F label="Client Name"><I value={newFu.clientName} onChange={e => setNewFu(f => ({...f,clientName:e.target.value}))} placeholder="Client name" /></F>
                    <F label="Company"><I value={newFu.company} onChange={e => setNewFu(f => ({...f,company:e.target.value}))} placeholder="Company" /></F>
                    <F label="Contact"><I value={newFu.contact} onChange={e => setNewFu(f => ({...f,contact:e.target.value}))} placeholder="Phone or email" /></F>
                    <F label="Last Contacted"><I value={newFu.last} onChange={e => setNewFu(f => ({...f,last:e.target.value}))} placeholder="e.g. June 20" /></F>
                    <F label="Follow-up Date"><I value={newFu.date} onChange={e => setNewFu(f => ({...f,date:e.target.value}))} placeholder="e.g. June 27" /></F>
                    <F label="Reason"><Sel value={newFu.reason} onChange={e => setNewFu(f => ({...f,reason:e.target.value}))} options={["Follow up on proposal","Check interest","Share portfolio","Reconnect","Negotiate terms","Other"]} /></F>
                  </div>
                  <F label="Notes" mb={12}><TA value={newFu.notes} onChange={e => setNewFu(f => ({...f,notes:e.target.value}))} placeholder="Context about this client..." rows={2} /></F>
                  <Btn label="Save Follow-up" onClick={() => { if (newFu.clientName) { setFus(f => [{ ...newFu, id: Date.now() }, ...f]); setNewFu({clientName:"",company:"",contact:"",last:"",date:"",reason:"Follow up on proposal",notes:""}); setShowFu(false); } }} variant="primary" size="sm" />
                </Card>}
                {fus.length === 0 && !showFu && <Card><div style={{ textAlign: "center", padding: "32px 0" }}><p style={{ color: T.su, fontSize: 14, margin: 0 }}>No follow-ups scheduled.</p></div></Card>}
                {fus.map(fu => <Card key={fu.id}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                    <div><div style={{ fontSize: 14, fontWeight: 600, color: T.tx }}>{fu.clientName}{fu.company && <span style={{ color: T.su, fontWeight: 400 }}> · {fu.company}</span>}</div><div style={{ fontSize: 12, color: T.su, marginTop: 2 }}>{fu.reason}</div>{fu.date && <div style={{ fontSize: 12, color: "#b45309", fontWeight: 500, marginTop: 2 }}>Due: {fu.date}</div>}</div>
                    <Btn label="Remove" onClick={() => setFus(f => f.filter(x => x.id !== fu.id))} variant="danger" size="sm" />
                  </div>
                  <Btn label={fuL && selFu?.id === fu.id ? "Generating..." : "Generate Follow-up Message"} onClick={() => { setFuMsg(null); setSelFu(fu); runAI(`Write a professional follow-up message in ${lang}: Client: ${fu.clientName} at ${fu.company}, Reason: ${fu.reason}, Last contacted: ${fu.last}, Notes: ${fu.notes||"N/A"}. Write 2 versions: 1) WhatsApp message (warm, concise, under 50 words) 2) Email (Subject + body under 80 words). Label: WhatsApp: and Email: Plain text only. Write in ${lang}.`, setFuMsg, setFuL); }} disabled={fuL && selFu?.id === fu.id} variant="secondary" size="sm" />
                  {selFu?.id === fu.id && fuMsg && <div style={{ marginTop: 12 }}>
                    <div style={{ background: T.in, border: `1px solid ${T.br}`, borderRadius: 7, padding: 12, marginBottom: 10 }}>
                      <pre style={{ whiteSpace: "pre-wrap", fontSize: 13, color: T.mi, lineHeight: 1.7, margin: 0, fontFamily: "'Georgia',serif" }}>{fuMsg}</pre>
                    </div>
                    <div style={{ display: "flex", gap: 8 }}>
                      <Btn label={copied==="fu"?"Copied!":"Copy"} onClick={() => copy(fuMsg, "fu")} variant="secondary" size="sm" />
                      <Btn label="Send via WhatsApp" onClick={() => openWA(fuMsg)} variant="primary" size="sm" />
                    </div>
                  </div>}
                </Card>)}
              </div>}

              {/* ─── NAMING ─── */}
              {tool === "naming" && <div>
                <div style={{ marginBottom: 20 }}><h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Business Name Generator</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>Find the perfect name for your business</p></div>
                <Card>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <F label="Industry / Business Type"><I value={nf.industry} onChange={e => setNf(f => ({...f,industry:e.target.value}))} placeholder="e.g. Web Design Agency" /></F>
                    <F label="Target Market"><I value={nf.market} onChange={e => setNf(f => ({...f,market:e.target.value}))} placeholder="e.g. Southeast Asia, Global" /></F>
                    <F label="Name Style"><Sel value={nf.style} onChange={e => setNf(f => ({...f,style:e.target.value}))} options={["Modern & Minimal","Classic & Professional","Bold & Memorable","Playful & Creative","Luxury & Premium","Tech-forward","Local & Authentic"]} /></F>
                    <F label="Keywords (optional)"><I value={nf.keywords} onChange={e => setNf(f => ({...f,keywords:e.target.value}))} placeholder="e.g. grow, trust, craft" /></F>
                  </div>
                  <Btn label={nl ? "Generating..." : `Generate Names in ${lang}`} onClick={() => runAI(`Expert brand naming consultant. Generate business names in ${lang} for: Industry: ${nf.industry}, Market: ${nf.market||"Global"}, Style: ${nf.style}, Keywords: ${nf.keywords||"none"}. Provide 10 unique business names. For each: name, brief rationale, domain tip. Then 3 tagline options for the strongest name. Be creative and strategic. Plain text only. Write in ${lang}.`, setNr, setNl)} disabled={!nf.industry || nl} variant="primary" full />
                </Card>
                <ResultBox text={nr} id="naming" filename="business_names.txt" />
              </div>}

              {/* ─── COMPETITOR ─── */}
              {tool === "competitor" && <div>
                <div style={{ marginBottom: 20 }}><h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Competitor Analysis</h2><p style={{ fontSize: 13, color: T.su, margin: 0 }}>Understand your market and outperform competitors</p></div>
                <Card>
                  <F label="Your Service / Offering"><I value={cf.service} onChange={e => setCf(f => ({...f,service:e.target.value}))} placeholder="e.g. Website Design for Small Businesses" /></F>
                  <F label="Your Location / Market"><I value={cf.location} onChange={e => setCf(f => ({...f,location:e.target.value}))} placeholder="e.g. Bangkok, Thailand" /></F>
                  <F label="Main Competitors (optional)" mb={12}><I value={cf.competitor} onChange={e => setCf(f => ({...f,competitor:e.target.value}))} placeholder="e.g. Wix, local agencies, Fiverr sellers" /></F>
                  <Btn label={cl2 ? "Analysing..." : `Analyse Market in ${lang}`} onClick={() => runAI(`Strategic market analyst. Provide competitor analysis in ${lang} for: My Service: ${cf.service}, My Market: ${cf.location}, Competitors: ${cf.competitor||"general market"}. Include: 1) How to differentiate clearly. 2) Unique selling points to highlight. 3) Pricing strategy vs market. 4) Marketing channels competitors underuse. 5) Specific tactics to win clients from competitors. Be specific and strategic. Plain text only. Write in ${lang}.`, setCr, setCl2)} disabled={!cf.service || !cf.location || cl2} variant="primary" full />
                </Card>
                <ResultBox text={cr} id="comp" filename="competitor_analysis.txt" />
              </div>}

              {/* ─── PROFILE ─── */}
              {tool === "profile" && <div>
                <div style={{ marginBottom: 20 }}><h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>My Profile</h2></div>
                <Card>
                  <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 20, paddingBottom: 16, borderBottom: `1px solid ${T.br}` }}>
                    <Avatar name={user.name} size={56} />
                    <div><div style={{ fontSize: 17, fontWeight: 700, color: T.tx }}>{user.name}</div><div style={{ fontSize: 13, color: T.su }}>{user.email}</div><div style={{ marginTop: 5 }}><Badge label={planLabel[user.plan||"free"]} color={planColor[user.plan||"free"]} /></div></div>
                  </div>
                  {editProfile ? <div>
                    {["name","businessName","phone","country"].map(k => <F key={k} label={k==="businessName"?"Business Name":k.charAt(0).toUpperCase()+k.slice(1)}><I value={pf[k]||""} onChange={e => setPf(f => ({...f,[k]:e.target.value}))} placeholder={`Enter ${k}`} /></F>)}
                    <div style={{ display: "flex", gap: 9 }}>
                      <Btn label="Cancel" onClick={() => setEditProfile(false)} variant="secondary" />
                      <Btn label="Save Changes" onClick={() => { setUser(u => ({...u,...pf})); setSavedUsers(us => us.map(u => u.email===user.email ? {...u,...pf} : u)); setEditProfile(false); }} variant="primary" />
                    </div>
                  </div> : <div>
                    {[["Full Name",user.name],["Email",user.email],["Business",user.businessName||"—"],["Phone",user.phone||"—"],["Country",user.country||"—"],["Member Since",user.joined]].map(([l,v]) => <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "10px 0", borderBottom: `1px solid ${T.br}` }}><span style={{ fontSize: 13, color: T.su, fontWeight: 500 }}>{l}</span><span style={{ fontSize: 13, color: v==="—"?T.su:T.tx, fontWeight: v==="—"?400:500 }}>{v}</span></div>)}
                    <div style={{ display: "flex", gap: 9, marginTop: 16 }}>
                      <Btn label="Edit Profile" onClick={() => { setPf({name:user.name,businessName:user.businessName||"",phone:user.phone||"",country:user.country||""}); setEditProfile(true); }} variant="primary" size="sm" />
                      <Btn label="Log Out" onClick={logout} variant="danger" size="sm" />
                    </div>
                  </div>}
                </Card>
              </div>}

              {/* ─── SETTINGS ─── */}
              {tool === "settings" && <div>
                <div style={{ marginBottom: 20 }}><h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Settings</h2></div>
                <Card>
                  <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>Appearance</div>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div><div style={{ fontSize: 14, fontWeight: 500, color: T.tx }}>Dark Mode</div><div style={{ fontSize: 12, color: T.su }}>Toggle between light and dark</div></div>
                    <button onClick={() => setDark(d => !d)} style={{ width: 44, height: 24, borderRadius: 12, border: "none", background: dark?"#7c3aed":"#d1d5db", cursor: "pointer", position: "relative", padding: 0 }}>
                      <div style={{ width: 18, height: 18, borderRadius: "50%", background: "#fff", position: "absolute", top: 3, left: dark?22:4, transition: "left 0.2s", boxShadow: "0 1px 3px rgba(0,0,0,0.2)" }} />
                    </button>
                  </div>
                </Card>
                <Card>
                  <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>Language</div>
                  <F label="Default Output Language" mb={0}><Sel value={lang} onChange={e => setLang(e.target.value)} options={LANGUAGES.map(l => l.code)} /></F>
                </Card>
                <Card>
                  <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>Account</div>
                  {[["Email",user.email],["Plan",planLabel[user.plan||"free"]],["Member Since",user.joined]].map(([l,v]) => <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "9px 0", borderBottom: `1px solid ${T.br}` }}><span style={{ fontSize: 13, color: T.su }}>{l}</span><span style={{ fontSize: 13, color: T.tx, fontWeight: 500 }}>{v}</span></div>)}
                  <div style={{ marginTop: 14 }}><Btn label="Log Out" onClick={logout} variant="danger" size="sm" /></div>
                </Card>
                <Card><div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 8 }}>About</div><p style={{ fontSize: 13, color: T.su, margin: 0, lineHeight: 1.6 }}>ClientAI v3.0 · 10 AI Tools · 24 Languages · Built for freelancers and business owners worldwide.</p></Card>
              </div>}

              {/* ─── UPGRADE ─── */}
              {tool === "upgrade" && <div>
                <div style={{ marginBottom: 20 }}>
                  <h2 style={{ fontSize: 18, fontWeight: 700, margin: "0 0 3px", color: T.tx }}>Upgrade Your Plan</h2>
                  <p style={{ fontSize: 13, color: T.su, margin: 0 }}>Unlock the full power of ClientAI</p>
                </div>

                {/* Billing + Currency toggles */}
                <div style={{ display: "flex", gap: 10, marginBottom: 22, flexWrap: "wrap" }}>
                  {/* Billing cycle */}
                  <div style={{ display: "flex", background: T.cd, border: `1px solid ${T.br}`, borderRadius: 8, padding: 4 }}>
                    {["monthly","yearly"].map(b => <button key={b} onClick={() => setBilling(b)} style={{ padding: "7px 16px", borderRadius: 6, border: "none", background: billing===b?"#7c3aed":"transparent", color: billing===b?"#fff":T.su, fontWeight: 600, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}>
                      {b==="monthly"?"Monthly":"Yearly"}{b==="yearly"&&<span style={{ background:"rgba(21,128,61,0.2)", color:"#15803d", borderRadius:4, padding:"1px 6px", fontSize:10, fontWeight:700 }}>-17%</span>}
                    </button>)}
                  </div>
                  {/* Currency toggle */}
                  <div style={{ display: "flex", background: T.cd, border: `1px solid ${T.br}`, borderRadius: 8, padding: 4 }}>
                    {[{id:"usd",flag:"🇺🇸",label:"USD $"},{id:"inr",flag:"🇮🇳",label:"INR ₹"}].map(c => <button key={c.id} onClick={() => setPayCurrency(c.id)} style={{ padding: "7px 16px", borderRadius: 6, border: "none", background: payCurrency===c.id?"#7c3aed":"transparent", color: payCurrency===c.id?"#fff":T.su, fontWeight: 600, fontSize: 13, cursor: "pointer", display: "flex", alignItems: "center", gap: 6 }}>
                      {c.flag} {c.label}
                    </button>)}
                  </div>
                </div>

                {/* Price cards */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 14, marginBottom: 20 }}>
                  {PLANS.map(p => {
                    const price = payCurrency === "inr" ? (billing==="yearly"?p.inr*10:p.inr) : (billing==="yearly"?p.usd*10:p.usd);
                    const sym = payCurrency === "inr" ? "₹" : "$";
                    const saving = payCurrency === "inr" ? `₹${p.inr*2}` : `$${p.usd*2}`;
                    return (
                      <div key={p.id} style={{ background: T.cd, border: p.id==="pro"?`2px solid ${T.ac}`:`1px solid ${T.br}`, borderRadius: 12, padding: 20, position: "relative" }}>
                        {p.badge && <div style={{ position: "absolute", top: -11, left: "50%", transform: "translateX(-50%)", background: p.id==="enterprise"?"#065f46":"#7c3aed", color: "#fff", fontSize: 11, fontWeight: 700, padding: "3px 12px", borderRadius: 4, whiteSpace: "nowrap" }}>{p.badge}</div>}
                        <div style={{ fontSize: 11, fontWeight: 700, color: p.color, textTransform: "uppercase", letterSpacing: "0.8px", marginBottom: 8 }}>{p.name}</div>
                        <div style={{ display: "flex", alignItems: "flex-end", gap: 4, marginBottom: 2 }}>
                          <span style={{ fontSize: 30, fontWeight: 800, color: T.tx, lineHeight: 1 }}>{price === 0 ? "Free" : `${sym}${price.toLocaleString()}`}</span>
                          {price > 0 && <span style={{ fontSize: 12, color: T.su, paddingBottom: 4 }}>/{billing==="monthly"?"mo":"yr"}</span>}
                        </div>
                        {/* Show both currencies */}
                        {price > 0 && <div style={{ fontSize: 11, color: T.su, marginBottom: 6 }}>
                          {payCurrency === "inr" ? `Also $${billing==="yearly"?p.usd*10:p.usd}/mo in USD` : `Also ₹${billing==="yearly"?p.inr*10:p.inr}/mo in INR`}
                        </div>}
                        {billing === "yearly" && price > 0 && <div style={{ fontSize: 11, color: T.gn, fontWeight: 600, marginBottom: 8 }}>Save {saving}/year</div>}
                        <Hr />
                        {p.features.map(f => <div key={f} style={{ display: "flex", gap: 7, marginBottom: 7 }}><span style={{ color: T.gn, fontSize: 12, fontWeight: 700, flexShrink: 0 }}>✓</span><span style={{ fontSize: 12, color: T.mi, lineHeight: 1.4 }}>{f}</span></div>)}
                        <div style={{ marginTop: 14 }}>
                          <Btn label={user.plan===p.id?"✓ Current Plan":price===0?"Start Free":`Get ${p.name}`}
                            onClick={() => { if (price > 0) { setUser(u=>({...u,plan:p.id})); setSavedUsers(us=>us.map(u=>u.email===user.email?{...u,plan:p.id}:u)); showToast(`Upgraded to ${p.name}! 🎉`); } }}
                            disabled={user.plan===p.id} variant={p.id==="pro"?"primary":p.id==="enterprise"?"secondary":"secondary"} full />
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Payment methods */}
                <Card>
                  <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>Accepted Payment Methods</div>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(160px,1fr))", gap: 10 }}>
                    {[
                      { icon:"🇮🇳", name:"UPI", desc:"Google Pay · PhonePe · Paytm", tag:"India", tagColor:"#f97316" },
                      { icon:"💳", name:"Razorpay", desc:"Cards · Net Banking · EMI", tag:"India", tagColor:"#f97316" },
                      { icon:"💳", name:"Stripe", desc:"Visa · Mastercard · Amex", tag:"Global", tagColor:"#7c3aed" },
                      { icon:"🅿️", name:"PayPal", desc:"Balance · Cards · Bank", tag:"Global", tagColor:"#7c3aed" },
                      { icon:"🏦", name:"Bank Transfer", desc:"NEFT · RTGS · IMPS · SWIFT", tag:"Both", tagColor:"#1d4ed8" },
                      { icon:"🔗", name:"Crypto", desc:"USDT · BTC · ETH", tag:"Global", tagColor:"#b45309" },
                    ].map(m => (
                      <div key={m.name} style={{ background: T.in, border: `1px solid ${T.br}`, borderRadius: 9, padding: "12px 14px" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 5 }}>
                          <span style={{ fontSize: 20 }}>{m.icon}</span>
                          <span style={{ fontSize: 9, fontWeight: 700, background: `${m.tagColor}18`, color: m.tagColor, border: `1px solid ${m.tagColor}30`, borderRadius: 3, padding: "1px 6px" }}>{m.tag}</span>
                        </div>
                        <div style={{ fontWeight: 700, fontSize: 13, color: T.tx, marginBottom: 2 }}>{m.name}</div>
                        <div style={{ fontSize: 11, color: T.su, lineHeight: 1.4 }}>{m.desc}</div>
                      </div>
                    ))}
                  </div>
                </Card>

                {/* Pricing comparison USD vs INR */}
                <Card>
                  <div style={{ fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.5px", marginBottom: 14 }}>Full Pricing — USD & INR</div>
                  <div style={{ overflowX: "auto" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
                      <thead>
                        <tr>
                          {["Plan","USD/mo","USD/yr","INR/mo","INR/yr","Features"].map(h => <th key={h} style={{ textAlign: "left", padding: "8px 10px", borderBottom: `1px solid ${T.br}`, fontSize: 11, fontWeight: 700, color: T.su, textTransform: "uppercase", letterSpacing: "0.4px" }}>{h}</th>)}
                        </tr>
                      </thead>
                      <tbody>
                        {PLANS.map((p,i) => <tr key={p.id} style={{ background: i%2===0?"transparent":dark?"rgba(255,255,255,0.02)":"rgba(0,0,0,0.01)" }}>
                          <td style={{ padding: "10px 10px", borderBottom: `1px solid ${T.br}` }}><span style={{ fontWeight: 700, color: p.color }}>{p.name}</span></td>
                          <td style={{ padding: "10px 10px", borderBottom: `1px solid ${T.br}`, color: T.tx, fontWeight: 600 }}>{p.usd===0?"Free":`$${p.usd}`}</td>
                          <td style={{ padding: "10px 10px", borderBottom: `1px solid ${T.br}`, color: T.gn, fontWeight: 600 }}>{p.usd===0?"Free":`$${p.usd*10}`}</td>
                          <td style={{ padding: "10px 10px", borderBottom: `1px solid ${T.br}`, color: T.tx, fontWeight: 600 }}>{p.inr===0?"Free":`₹${p.inr}`}</td>
                          <td style={{ padding: "10px 10px", borderBottom: `1px solid ${T.br}`, color: T.gn, fontWeight: 600 }}>{p.inr===0?"Free":`₹${(p.inr*10).toLocaleString()}`}</td>
                          <td style={{ padding: "10px 10px", borderBottom: `1px solid ${T.br}`, color: T.su, fontSize: 12 }}>{p.features.length} features</td>
                        </tr>)}
                      </tbody>
                    </table>
                  </div>
                </Card>

                <Card extra={{ borderColor: T.ab, background: T.al }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontSize: 24 }}>🇮🇳</span>
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14, color: T.tx, marginBottom: 2 }}>Special India Pricing</div>
                      <div style={{ fontSize: 13, color: T.mi }}>INR pricing is 80% cheaper than USD — making ClientAI accessible for every Indian freelancer and business owner.</div>
                    </div>
                  </div>
                </Card>

                <p style={{ fontSize: 12, color: T.su, textAlign: "center", marginTop: 4 }}>🔒 Secure payments · Cancel anytime · Instant access after payment</p>
              </div>}

            </div>
          </main>
        </div>

        {/* BOTTOM NAV (mobile) */}
        <div style={{ position: "fixed", bottom: 0, left: 0, right: 0, background: T.hd, borderTop: `1px solid ${T.br}`, display: "flex", padding: "6px 0 10px", zIndex: 100, backdropFilter: "blur(12px)" }}>
          {[
            {id:"dashboard", icon:"⊞", l:"Home"},
            {id:"generate",  icon:"⚡", l:"Strategy"},
            {id:"tracker",   icon:"👥", l:"Clients"},
            {id:"invoice",   icon:"🧾", l:"Invoice"},
            {id:"profile",   icon:"👤", l:"Profile"},
          ].map(s => (
            <button key={s.id} onClick={() => setTool(s.id)} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3, padding: "5px 2px", borderRadius: 8, border: "none", background: "transparent", cursor: "pointer", color: tool===s.id ? T.ac : T.su, transition: "color 0.15s" }}>
              <span style={{ fontSize: 18, lineHeight: 1 }}>{s.icon}</span>
              <span style={{ fontSize: 9, fontWeight: tool===s.id ? 700 : 400, letterSpacing: "0.2px" }}>{s.l}</span>
              {tool === s.id && <div style={{ width: 18, height: 2, borderRadius: 1, background: T.ac, marginTop: 1 }} />}
            </button>
          ))}
        </div>
      </div>
      </>
    );
  }

  return null;
}
